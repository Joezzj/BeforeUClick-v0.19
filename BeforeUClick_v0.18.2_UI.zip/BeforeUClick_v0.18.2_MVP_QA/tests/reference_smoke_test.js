// tests/reference_smoke_test.js
// Lightweight Node smoke tests for Reference Dataset v1.0 and evidence scoring.
// Run from the project root with: node tests/reference_smoke_test.js

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const context = vm.createContext({ console, URL, setTimeout, clearTimeout });

const files = [
    "data/public_suffix_rules.js",
    "data/evidence_classes.js",
    "data/organisation_references.js",
    "data/controlled_namespaces.js",
    "data/wording_patterns.js",
    "data/email_provider_references.js",
    "analysis/domains.js",
    "analysis/references.js",
    "analysis/evidence.js",
    "analysis/similarity.js",
    "analysis/brands.js",
    "analysis/wording.js",
    "analysis/sender.js",
    "analysis/metadata.js",
    "analysis/risk.js",
    "analysis/scoring.js"
];

for (const relative of files) {
    const source = fs.readFileSync(path.join(root, relative), "utf8");
    vm.runInContext(source, context, { filename: relative });
}

vm.runInContext(`
    function assert(condition, message) {
        if (!condition) throw new Error(message);
    }

    const microsoft = bucDescribeDomainReference("login.microsoft.com");
    assert(microsoft.officialOrganisation?.id === "microsoft", "Microsoft should be a first-party destination.");
    assert(microsoft.scoreKeys.includes("OFFICIAL_DESTINATION"), "Microsoft first-party score key missing.");

    const sharepoint = bucDescribeDomainReference("tenant.sharepoint.com");
    assert(sharepoint.recognisedOrganisation?.id === "microsoft", "SharePoint should be recognised as Microsoft.");
    assert(!sharepoint.officialOrganisation, "SharePoint tenant content must not receive first-party destination reassurance.");
    assert(sharepoint.isUserContent, "SharePoint should be marked user-content/platform.");

    const dropbox = bucDescribeDomainReference("www.dropbox.com");
    assert(dropbox.recognisedOrganisation?.id === "dropbox", "Dropbox should be recognised.");
    assert(!dropbox.officialOrganisation, "Dropbox shared-content platform should be score-neutral for destination reassurance.");

    const nzpost = bucDescribeDomainReference("www.nzpost.co.nz");
    assert(nzpost.officialOrganisation?.id === "nzpost", "NZ Post should be a first-party destination.");

    const govt = bucDescribeDomainReference("example.govt.nz");
    assert(govt.controlledNamespace?.suffix === "govt.nz", "govt.nz moderated namespace should be recognised.");

    const wording = checkWording("URGENT: share your verification code immediately so we can restore your account.");
    const mfa = wording.matches.find(item => item.id === "mfa-code-request");
    assert(mfa?.evidenceClass === "WORDING_STRONG", "MFA request should use WORDING_STRONG.");
    assert(wording.score <= 15, "Wording must remain capped at 15.");

    const officialSender = analyseSender("security@microsoft.com", "Microsoft Security");
    assert(officialSender.evidence.some(item => item.points < 0), "Official Microsoft sender should produce reassuring evidence.");

    const fakeSender = analyseSender("someone@gmail.com", "Microsoft Security");
    assert(fakeSender.evidence.some(item => item.code === "sender-brand-on-freemail" && item.points > 0), "Microsoft claim on Gmail should be concerning.");

    const mismatch = calculateLinkRisk("microsoft.com", "https://example.invalid/login");
    assert(mismatch.warnings.some(item => item.code === "display-mismatch"), "Displayed/actual domain mismatch should be detected.");

    const sharepointBrand = calculateLinkRisk("Microsoft SharePoint", "https://tenant.sharepoint.com/document");
    assert(!sharepointBrand.warnings.some(item => item.code === "brand-domain-inconsistency"), "Recognised Microsoft SharePoint platform should not be called brand impersonation.");

    const officialLinkScore = scoreBeforeUClickEvidence({
        senderResult: { evidence: [], score: 0 },
        metadataResult: { evidence: [], score: 0 },
        bodyIdentityResult: { evidence: [], score: 0 },
        wordingResult: { matches: [], score: 0 },
        links: [{
            id: "LINK-OFFICIAL", text: "Microsoft", url: "https://www.microsoft.com/", type: "text",
            score: 0, warningDetails: [], domain: bucDescribeUrl("https://www.microsoft.com/"),
            reference: bucDescribeDomainReference("www.microsoft.com")
        }]
    });
    assert(officialLinkScore.score < 15, "First-party official link should provide reassurance.");

    const platformLinkScore = scoreBeforeUClickEvidence({
        senderResult: { evidence: [], score: 0 },
        metadataResult: { evidence: [], score: 0 },
        bodyIdentityResult: { evidence: [], score: 0 },
        wordingResult: { matches: [], score: 0 },
        links: [{
            id: "LINK-PLATFORM", text: "SharePoint", url: "https://tenant.sharepoint.com/file", type: "text",
            score: 0, warningDetails: [], domain: bucDescribeUrl("https://tenant.sharepoint.com/file"),
            reference: bucDescribeDomainReference("tenant.sharepoint.com")
        }]
    });
    assert(platformLinkScore.score === 15, "Platform/user-content link alone must remain neutral at baseline 15.");

    const baseScore = scoreBeforeUClickEvidence({
        senderResult: { evidence: [], score: 0 },
        metadataResult: { evidence: [], score: 0 },
        bodyIdentityResult: { evidence: [], score: 0 },
        wordingResult: { matches: [], score: 0 },
        links: []
    });
    assert(baseScore.score === 15, "Unknown baseline should remain 15.");

    const positiveScore = scoreBeforeUClickEvidence({
        senderResult: officialSender,
        metadataResult: { evidence: [], score: 0 },
        bodyIdentityResult: { evidence: [], score: 0 },
        wordingResult: { matches: [], score: 0 },
        links: []
    });
    assert(positiveScore.score < 15, "Explicit official sender evidence should reduce score below 15.");

    globalThis.__bucResults = {
        organisationCount: BUC_ORGANISATION_REFERENCES.length,
        wordingCount: BUC_WORDING_PATTERN_GROUPS.length,
        microsoft: microsoft.primaryRule,
        sharepointRoles: sharepoint.roles,
        wordingScore: wording.score,
        baseScore: baseScore.score,
        positiveScore: positiveScore.score,
        officialLinkScore: officialLinkScore.score,
        platformLinkScore: platformLinkScore.score
    };
`, context, { filename: "reference-smoke-assertions.js" });

console.log("BeforeUClick v0.13 reference/scoring smoke tests: PASS");
console.log(context.__bucResults);
