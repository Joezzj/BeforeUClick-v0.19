// analysis/risk.js
// Explainable URL evidence checks using role-aware reference data.
// Link observations feed the separate evidence-weighted scoring engine in scoring.js.

/**
 * Creates a standard warning object used by the link-analysis pipeline.
 */
function bucRiskWarning(code, score, text, strength = "weak") {
    return { code, category: "link", source: "link", score, points: score, text, strength };
}

/**
 * Parses visible link text when it appears to be a URL/domain rather than ordinary button text.
 */
function bucDisplayedUrl(text) {
    const value = String(text || "").trim();
    if (!value || /\s/.test(value)) return null;

    let candidate = value;
    if (!/^https?:\/\//i.test(candidate)) {
        if (!/^(?:www\.)?[a-z0-9.-]+\.[a-z]{2,}(?:[/:?#].*)?$/i.test(candidate)) {
            return null;
        }
        candidate = `https://${candidate}`;
    }

    try {
        return new URL(candidate);
    } catch (_error) {
        return null;
    }
}

/**
 * Removes weak URL-path warnings that are expected on a locally recognised official domain.
 * Strong structural warnings are never removed by this helper.
 */
function bucSuppressWeakOfficialDomainWarnings(warnings, reference) {
    if (!(reference?.officialOrganisation || reference?.shortLinkOrganisation)) return warnings;

    const suppressibleCodes = new Set(["url-word", "long-url"]);
    return warnings.filter(warning => !suppressibleCodes.has(warning.code));
}

/**
 * Performs local, explainable URL checks and returns score, warnings and domain/reference context.
 */
function calculateLinkRisk(linkText, destination) {
    let parsed;

    try {
        parsed = new URL(destination);
    } catch (_error) {
        return {
            score: 20,
            warnings: [bucRiskWarning("invalid-url", 20, "The destination URL could not be parsed.", "medium")],
            domain: null,
            reference: null
        };
    }

    const domain = bucDescribeUrl(destination);
    const reference = bucDescribeDomainReference(parsed.hostname);
    const hostname = domain?.hostname || parsed.hostname.toLowerCase();
    const warnings = [];

    if (parsed.protocol === "http:") {
        warnings.push(bucRiskWarning("http", 10, "The link uses HTTP rather than HTTPS.", "weak"));
    }

    if (domain?.isIpAddress) {
        warnings.push(bucRiskWarning("ip-host", 25, "The link uses a raw IP address instead of a normal domain name.", "strong"));
    }

    const shorteners = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly"];
    if (shorteners.some(shortener => bucHostnameMatchesDomain(hostname, shortener))) {
        warnings.push(bucRiskWarning("shortener", 15, "A URL shortener hides the final destination from the user.", "medium"));
    }

    if (hostname.split(".").some(label => label.startsWith("xn--"))) {
        warnings.push(bucRiskWarning("punycode", 20, "The destination domain contains punycode/IDN encoding.", "medium"));
    }

    const typosquat = bucFindTyposquatReference(hostname);
    if (typosquat) {
        warnings.push(bucRiskWarning(
            "typosquat-domain",
            28,
            `Destination domain ${typosquat.candidateDomain} is very close to recognised ${typosquat.organisation.name} domain ${typosquat.officialDomain}.`,
            "strong"
        ));
    }

    if (domain?.subdomain && domain.subdomain.split(".").filter(Boolean).length > 3) {
        warnings.push(bucRiskWarning("subdomains", 10, "The destination has an unusually long chain of subdomains.", "weak"));
    }

    if (parsed.username || parsed.password) {
        warnings.push(bucRiskWarning("userinfo", 20, "The URL contains user-information before the hostname, which can make a destination misleading.", "strong"));
    }

    if (parsed.port && !["80", "443"].includes(parsed.port)) {
        warnings.push(bucRiskWarning("port", 8, `The link uses unusual network port ${parsed.port}.`, "weak"));
    }

    if (hostname.length > 55 || parsed.href.length > 180) {
        warnings.push(bucRiskWarning("long-url", 5, "The destination URL is unusually long.", "weak"));
    }

    const displayed = bucDisplayedUrl(linkText);
    if (displayed) {
        const displayedDomain = bucParseDomain(displayed.hostname);
        const destinationDomain = bucParseDomain(hostname);
        const displayedComparable = displayedDomain.registrableDomain || displayedDomain.hostname;
        const destinationComparable = destinationDomain.registrableDomain || destinationDomain.hostname;

        if (displayedComparable && destinationComparable && displayedComparable !== destinationComparable) {
            warnings.push(bucRiskWarning(
                "display-mismatch",
                35,
                `Displayed address belongs to ${displayedComparable}, but the actual destination belongs to ${destinationComparable}.`,
                "strong"
            ));
        }
    }

    const suspiciousTerms = [
        "login", "signin", "verify", "verification", "password", "account",
        "suspended", "confirm", "update", "payment", "invoice", "wallet",
        "bank", "recover", "reset", "unlock"
    ];

    const pathAndQuery = `${parsed.pathname}${parsed.search}`.toLowerCase();
    const matchedTerms = suspiciousTerms.filter(term => pathAndQuery.includes(term));

    matchedTerms.slice(0, 3).forEach(term => {
        warnings.push(bucRiskWarning(
            "url-word",
            4,
            `Security-sensitive word appears in the URL path or query: "${term}".`,
            "weak"
        ));
    });

    warnings.push(...checkBrandImpersonation(destination, linkText));

    const finalWarnings = bucSuppressWeakOfficialDomainWarnings(warnings, reference);

    // Weak URL-shape clues are useful context but should not stack indefinitely until an
    // ordinary tracking/marketing URL looks equivalent to a strong identity mismatch.
    const weakWarnings = finalWarnings.filter(warning => (warning.strength || "weak") === "weak");
    const strongerWarnings = finalWarnings.filter(warning => (warning.strength || "weak") !== "weak");
    const weakRawScore = weakWarnings.reduce((total, warning) => total + (warning.score || 0), 0);
    const strongerScore = strongerWarnings.reduce((total, warning) => total + (warning.score || 0), 0);
    const weakCap = BUC_SCORING_MODEL?.weakLinkCap || 8;
    const weakAppliedScore = Math.min(weakRawScore, weakCap);
    const rawScore = weakRawScore + strongerScore;
    const score = Math.min(weakAppliedScore + strongerScore, 100);

    return {
        score,
        rawScore,
        weakRawScore,
        weakAppliedScore,
        weakCap,
        warnings: finalWarnings,
        domain,
        reference
    };
}
