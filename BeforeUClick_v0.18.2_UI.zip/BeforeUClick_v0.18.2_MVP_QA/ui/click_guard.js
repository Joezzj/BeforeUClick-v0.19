// ui/click_guard.js
// Risk-sensitive confirmation UI for links already analysed by BeforeUClick.
// The guard does not analyse URLs itself; it uses the exact link result produced by the normal pipeline.

let bucClickGuardMode = "strong-only";
let bucClickGuardEngaged = false;

/** Updates the current in-memory click-guard policy from local preferences. */
function bucSetClickGuardMode(mode) {
    const allowed = new Set(["strong-only", "high-only", "caution-high", "off"]);
    bucClickGuardMode = allowed.has(mode) ? mode : "strong-only";
}

/** Enables/disables click interruption for the current explicit manual-check session. */
function bucSetClickGuardEngaged(engaged) {
    bucClickGuardEngaged = engaged === true;
    if (!bucClickGuardEngaged) bucCloseClickGuard();
}

let bucClickGuardInstalled = false;
let bucClickGuardBypassAnchor = null;

/**
 * Returns true when a previously analysed link has enough evidence to justify interrupting a normal click.
 */
function bucShouldGuardLink(link) {
    if (!bucClickGuardEngaged || !link || bucClickGuardMode === "off") return false;

    const state = typeof bucLinkHighlightState === "function"
        ? bucLinkHighlightState(link)
        : { key: (Number(link.score) || 0) >= 50 ? "high" : "unknown" };
    const hasStrongEvidence = (link.warningDetails || []).some(warning =>
        warning.strength === "strong" || warning.strength === "critical"
    );

    if (bucClickGuardMode === "high-only") {
        return state.key === "high";
    }

    if (bucClickGuardMode === "caution-high") {
        return state.key === "high" || state.key === "caution";
    }

    // Default mode: high concern OR an explicit strong/critical reason.
    return state.key === "high" || hasStrongEvidence;
}

/**
 * Removes any open BeforeUClick click-guard confirmation panel.
 */
function bucCloseClickGuard() {
    document.getElementById("beforeuclick-click-guard")?.remove();
}

/**
 * Creates a safe text-only DOM element for the click-guard panel.
 */
function bucGuardElement(tag, text = "") {
    const element = document.createElement(tag);
    if (text) element.textContent = text;
    return element;
}

/**
 * Continues the original email link action once, bypassing the guard for the synthetic follow-up click.
 */
function bucContinueGuardedLink(anchor) {
    if (!anchor || !document.contains(anchor)) return;
    bucClickGuardBypassAnchor = anchor;
    bucCloseClickGuard();
    anchor.click();
    setTimeout(() => {
        if (bucClickGuardBypassAnchor === anchor) bucClickGuardBypassAnchor = null;
    }, 0);
}

/**
 * Shows a non-destructive confirmation dialog tied to one specific analysed link.
 */
function bucShowClickGuard(link, anchor) {
    bucCloseClickGuard();

    const linkValues = typeof bucCurrentAnalysedLinks !== "undefined"
        ? Array.from(bucCurrentAnalysedLinks.values())
        : [];
    const linkIndex = linkValues.findIndex(item => item.id === link.id);
    const linkLabel = linkIndex >= 0 ? `Link ${linkIndex + 1}` : "This link";

    const overlay = bucGuardElement("div");
    overlay.id = "beforeuclick-click-guard";
    Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483647",
        background: "rgba(32,33,36,.48)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
        boxSizing: "border-box"
    });

    const dialog = bucGuardElement("section");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-labelledby", "beforeuclick-click-guard-title");
    Object.assign(dialog.style, {
        width: "min(520px, 100%)",
        maxHeight: "80vh",
        overflowY: "auto",
        background: "#ffffff",
        color: "#202124",
        borderRadius: "12px",
        border: "1px solid #dadce0",
        boxShadow: "0 12px 36px rgba(0,0,0,.35)",
        padding: "18px",
        fontFamily: "Arial, Helvetica, sans-serif",
        boxSizing: "border-box"
    });

    const title = bucGuardElement("h2", "⚠ Before you leave this email");
    title.id = "beforeuclick-click-guard-title";
    Object.assign(title.style, { margin: "0 0 8px", fontSize: "20px" });

    const state = typeof bucLinkHighlightState === "function"
        ? bucLinkHighlightState(link)
        : { key: "caution", label: "Caution" };
    const concernPhrase = state.key === "high" ? "a high concern" : "a concern worth checking";
    const intro = bucGuardElement(
        "p",
        `BeforeUClick found ${concernPhrase} with ${linkLabel}. Are you sure you want to open it?`
    );
    Object.assign(intro.style, { margin: "0 0 12px", lineHeight: "1.45" });

    const destinationLabel = bucGuardElement("strong", "Actual destination");
    const destination = bucGuardElement("div", link.url || "Destination unavailable");
    Object.assign(destination.style, {
        marginTop: "4px",
        padding: "9px 10px",
        background: "#f8f9fa",
        border: "1px solid #e5e7eb",
        borderRadius: "7px",
        overflowWrap: "anywhere",
        fontFamily: "Consolas, 'Courier New', monospace",
        fontSize: "12px"
    });

    const reasonsTitle = bucGuardElement("strong", "Why BeforeUClick is asking");
    Object.assign(reasonsTitle.style, { display: "block", marginTop: "14px" });

    const reasons = bucGuardElement("ul");
    Object.assign(reasons.style, { paddingLeft: "20px", margin: "7px 0 0" });
    const warningTexts = (link.warnings || []).slice(0, 5);
    (warningTexts.length ? warningTexts : ["This link reached the click-guard threshold."]).forEach(text => {
        const item = bucGuardElement("li", text);
        item.style.marginBottom = "5px";
        reasons.appendChild(item);
    });

    const note = bucGuardElement(
        "p",
        "This warning is not a guarantee that the destination is malicious. If you were not expecting this link, verify it another way before continuing."
    );
    Object.assign(note.style, {
        color: "#5f6368",
        fontSize: "12px",
        lineHeight: "1.4",
        margin: "14px 0 0"
    });

    const actions = bucGuardElement("div");
    Object.assign(actions.style, {
        display: "flex",
        justifyContent: "flex-end",
        gap: "8px",
        flexWrap: "wrap",
        marginTop: "16px"
    });

    const goBack = bucGuardElement("button", "Go back");
    goBack.type = "button";
    Object.assign(goBack.style, {
        border: "0",
        borderRadius: "8px",
        padding: "9px 14px",
        background: "#1a73e8",
        color: "#ffffff",
        fontWeight: "600",
        cursor: "pointer"
    });

    const openAnyway = bucGuardElement("button", "Open anyway");
    openAnyway.type = "button";
    Object.assign(openAnyway.style, {
        border: "1px solid #dadce0",
        borderRadius: "8px",
        padding: "9px 14px",
        background: "#ffffff",
        color: "#3c4043",
        fontWeight: "600",
        cursor: "pointer"
    });

    goBack.addEventListener("click", bucCloseClickGuard);
    openAnyway.addEventListener("click", () => bucContinueGuardedLink(anchor));

    actions.append(goBack, openAnyway);
    dialog.append(title, intro, destinationLabel, destination, reasonsTitle, reasons, note, actions);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    goBack.focus();

    overlay.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            event.preventDefault();
            bucCloseClickGuard();
        }
    });
}

/**
 * Installs one capture-phase click listener. Only links from the most recently analysed email are eligible.
 * Modified clicks (Ctrl/Cmd/Shift/Alt) are left untouched in this prototype.
 */
function bucInstallClickGuard() {
    if (bucClickGuardInstalled) return;
    bucClickGuardInstalled = true;

    window.addEventListener("click", event => {
        if (event.defaultPrevented || event.button !== 0) return;
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;

        const target = event.target instanceof Element ? event.target : null;
        const anchor = target?.closest("a[href]");
        if (!anchor) return;

        if (bucClickGuardBypassAnchor === anchor) {
            bucClickGuardBypassAnchor = null;
            return;
        }

        const analysed = typeof bucFindAnalysedLinkForAnchor === "function"
            ? bucFindAnalysedLinkForAnchor(anchor)
            : null;
        if (!analysed?.link || !bucShouldGuardLink(analysed.link)) return;

        event.preventDefault();
        event.stopImmediatePropagation();
        bucShowClickGuard(analysed.link, anchor);
    }, true);
}
