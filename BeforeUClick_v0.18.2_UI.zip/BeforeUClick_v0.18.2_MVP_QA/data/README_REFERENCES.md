# BeforeUClick Data References — Reference Dataset v1.0

Reference numbers are global across the BeforeUClick data files.

Reviewed: 7 September 2026.

## Domain structure / namespace

[1] Public Suffix List Project, "Learn more about the Public Suffix List."
https://publicsuffix.org/learn/
Used for: public-suffix and registrable-domain methodology.

[2] InternetNZ, ".nz Rules," version 3.2, effective 17 March 2026.
https://internetnz.nz/nz-domains/nz-rules-and-schedules/nz-rules/
Used for: moderated/restricted `.nz` namespaces.

## General phishing / scam behaviour

[3] CERT NZ / NCSC New Zealand, "Quarter Four Cyber Security Insights 2023."
https://www.cert.govt.nz/insights-and-research/quarterly-report/quarter-four-cyber-security-insights-2023/
Used for: impersonation, lookalike domains, urgency, shorteners, credential harvesting, payment lures and malware.

[4] NCSC New Zealand, "Focus area: Spoof and spam."
https://www.ncsc.govt.nz/insights-and-research/insights-reports/quarter-two-cyber-security-insights/spoof-and-spam/
Used for: sender/domain impersonation, Reply-To differences, unexpected requests and SPF/DKIM/DMARC context.

[5] NCSC New Zealand, "Phishing Disruption Service."
https://www.ncsc.govt.nz/what-we-do/services-we-offer/phishing-disruption-service/
Used for: possible future verified NZ-specific phishing indicators.

[6] U.S. Federal Trade Commission, "How To Recognize and Avoid Phishing Scams."
https://consumer.ftc.gov/articles/how-recognize-avoid-phishing-scams
Used for: unexpected messages, links/attachments and requests for account/personal information.

[7] U.S. Federal Trade Commission, "Avoiding and Reporting Gift Card Scams."
https://consumer.ftc.gov/articles/avoiding-and-reporting-gift-card-scams
Used for: urgency, gift-card payment, PIN/code requests and secrecy.

[8] Anti-Phishing Working Group, "Phishing Activity Trends Reports."
https://apwg.org/trendreports
Used for: phishing/BEC/impersonation trend monitoring.

## Existing NZ organisation sources

[9] NZ Post, "Scams & fraud."
https://www.nzpost.co.nz/contact-support/scams-and-fraud
Used for: nzpost.co.nz, nzp.st and NZ Post scam patterns.

[10] Inland Revenue New Zealand, "Latest scams."
https://www.ird.govt.nz/managing-my-tax/scams/latest-scams
Used for: ird.govt.nz and IRD scam behaviour.

[11] ASB Bank, "ASB Scam Update."
https://www.asb.co.nz/banking-with-asb/security-alerts.html
Used for: asb.co.nz and password/PIN/MFA/remote-access guidance.

[12] BNZ, "Recognising scams."
https://www.bnz.co.nz/about-us/online-security/recognising-scams
Used for: bnz.co.nz, urgency, generic greetings, unexpected contact and payment/link requests.

[13] Westpac New Zealand, "Latest scams & alerts."
https://www.westpac.co.nz/personal/ways-to-bank/safety-and-security/latest-scams/
Used for: westpac.co.nz, impersonation, login-link and verification-code patterns.

[14] ANZ New Zealand, "Bank impersonation website scams," May 2026.
https://www.anz.co.nz/banking-with-anz/banking-safely/recognise-scams-fraud/latest-scams/may-2026-bank-impersonation-website-scams/
Used for: anz.co.nz, fake-bank websites and urgent-account/remote-access patterns.

[15] Kiwibank, "Phishing emails & text messages."
https://www.kiwibank.co.nz/help/fraud-scams/types-of-scams/phishing/
Used for: kiwibank.co.nz, urgency, account threats, personal information, attachments and suspicious links.

[16] Kiwibank, "Altered invoice scams."
https://www.kiwibank.co.nz/help/fraud-scams/types-of-scams/altered-invoice/
Used for: changed bank details and payment-redirection patterns.

[17] Spark New Zealand, "Keep safe from scams."
https://www.spark.co.nz/help/privacy-and-safety/scams-safety/current-scams
Used for: spark.co.nz, password/account update, fake invoice, storage and remote-access patterns.

[18] One New Zealand, "Our guide to dealing with fraud and scams."
https://one.nz/help/frauds-scams-and-safety/
Used for: one.nz, account problems, unusual links, PIN/password and fake-login patterns.

[19] 2degrees, "Scam or phishing calls and messages."
https://www.2degrees.nz/help/mobile-help/security/scam-or-phishing-calls-and-messages
Used for: 2degrees.nz, fake warnings, overdue payments, remote access and credential harvesting.

[20] Trade Me, "Phishing emails and messages."
https://help.trademe.co.nz/hc/en-us/articles/360007001332-Phishing-emails-and-messages
Used for: trademe.co.nz and documented sender-domain references.

[21] NZ Transport Agency Waka Kotahi, "Latest phishing scams."
https://www.nzta.govt.nz/online-services/phishing-scams/latest-phishing-scams/
Used for: nzta.govt.nz, toll, vehicle-licence and payment themes.

## Existing global organisation sources

[22] PayPal, "Protect Your PayPal Account."
https://www.paypal.com/us/security/protect-your-account
Used for: paypal.com and password/one-time-code behaviour.

[23] Microsoft Support, "What is cloud.microsoft?"
https://support.microsoft.com/en-us/office/what-is-cloud-microsoft
Used for: microsoft.com / cloud.microsoft and the Microsoft-controlled `.microsoft` namespace.

[24] Microsoft, "Microsoft.com Site Map."
https://www.microsoft.com/en-us/sitemap/
Used for: Microsoft / Microsoft 365 / Outlook product/domain context.

[25] Google Account Help, "Use Gmail to access your Google Account."
https://support.google.com/accounts/answer/76194?hl=en
Used for: Google Account / Gmail web references.

[26] Google Gmail Help, "Write & send email."
https://support.google.com/mail/answer/9259768?hl=en
Used for: mail.google.com / Gmail context.

[27] Apple, "iCloud+."
https://www.apple.com/icloud/
Used for: apple.com and icloud.com.

## Threat intelligence

[28] PhishTank, "Developer Information."
https://www.phishtank.org/developer_info.php
Used for: future verified currently-online phishing URL feed.

[29] OpenPhish, "Phishing Feeds."
https://openphish.com/phishing_feeds.html
Used for: future phishing URL feed.

[30] URLhaus / abuse.ch, "Community API."
https://urlhaus.abuse.ch/api/
Used for: future malware-distribution URL data.

[31] Spamhaus, "Domain Blocklist (DBL)."
https://www.spamhaus.org/blocklists/domain-blocklist/
Used for: future phishing/malware/fraud/abused-domain reputation evidence.

[32] Google Safe Browsing, "Local List Mode."
https://developers.google.com/safe-browsing/reference/Local.List.Mode
Used for: possible future privacy-conscious local hash-prefix threat checking.

## New global organisation / wording sources

[33] LinkedIn Help, "Phishing content" and "Warning Signs of Fraudulent Messages."
https://www.linkedin.com/help/recruiter/answer/a1339266
https://www.linkedin.com/help/linkedin/answer/a1339438/
Used for: LinkedIn sender domains, urgency, attachments, personal/financial requests, investment and job-scam patterns.

[34] Dropbox Help, "What official domains does Dropbox use?" and "How to protect yourself from phishing and viruses."
https://help.dropbox.com/security/official-domains
https://help.dropbox.com/security/phishing-virus-protection
Used for: Dropbox verified domains, sender domains, user-content distinction, fake-login/file-share and urgency patterns.

[35] Adobe, "Allow required domains for Adobe apps and services" and Adobe Trust Center incident response.
https://helpx.adobe.com/business/enterprise/manage-services/configure-services/network-endpoints.html
https://www.adobe.com/trust/security/incident-response.html
Used for: adobe.com, adobelogin.com, adobe-identity.com and Adobe phishing guidance.

[36] Netflix Help Center, "Phishing or suspicious emails or texts claiming to be from Netflix."
https://help.netflix.com/en/node/65674
Used for: netflix.com and personal/payment/password request patterns.

[37] Docusign Safety Center and fraud alerts.
https://www.docusign.com/safety
https://www.docusign.com/trust/safety-alerts
Used for: docusign.com/docusign.net, platform-abuse caveat, document/e-sign, QR/quishing, fake billing/support and urgency patterns.

[38] Xero, "Security at Xero."
https://www.xero.com/au/security/
Used for: xero.com and phishing/malicious-email guidance.

[39] DHL, "Protect Yourself Against Scams, Phishing, and Smishing" / phishing-site advisory.
https://www.dhl.com/discover/en-nz/logistics-advice/essential-guides/protect-yourself-against-scams
https://www.dhl.com/discover/en-au/about-dhl/phishing-site-scam-call-advisory
Used for: dhl.com, express.dhl, dpdhl.com, dhl-news.com and delivery/OTP/shortened-URL patterns.

[40] FedEx, "How to Recognize and Help Prevent Fraud and Scams."
https://www.fedex.com/en-us/report-fraud.html
Used for: fedex.com and package/payment scam patterns.

[41] UPS, "Protect Yourself From Fraud and Scams."
https://www.ups.com/us/en/support/shipping-support/legal-terms-conditions/fight-fraud
Used for: ups.com, urgency, generic greeting, typosquatting, package/payment and deceptive-link patterns.

## New NZ organisation / wording sources

[42] ACC New Zealand, "Staying safe online."
https://www.acc.co.nz/about-us/about-this-site/staying-safe-online
Used for: acc.co.nz, ext.acc.nz, urgent pressure, overdue levy/refund/login issues, fake links, remote access and sensitive-information requests.

[43] New Zealand Police, "Fraud/Scam/Cyber" and scam guidance.
https://www.police.govt.nz/use-105/fraud-scam-cyber
Used for: police.govt.nz, phishing/banking/job/inheritance/lottery scam categories.

[44] Work and Income New Zealand, "Online security."
https://www.workandincome.govt.nz/about-this-site/security.html
Used for: workandincome.govt.nz and phishing/login/password guidance.

[45] RealMe, "RealMe Home," "Help," and Terms of use.
https://www.realme.govt.nz/en-nz/
https://www.realme.govt.nz/en-nz/help/
https://www.realme.govt.nz/en-nz/terms-use/realme-terms-use/
Used for: realme.govt.nz / login.realme.govt.nz and password/PIN/one-time-code guidance.

[46] Contact Energy, "Staying safe online."
https://contact.co.nz/support/my-account/staying-safe-online
Used for: contact.co.nz and payment/PIN/password/link-safety patterns.

[47] Mercury, "Scams and Phishing."
https://ask.mercury.co.nz/app/answers/detail/a_id/1298/~/scams-and-phishing
Used for: mercury.co.nz and urgency, payment, app-install and personal/banking detail patterns.

[48] Meridian Energy, "Managing your account" / scam reporting.
https://www.meridianenergy.co.nz/help/for-business-and-farm/managing-your-account
Used for: meridianenergy.co.nz and card/bank-detail email-safety guidance.

[49] Genesis Energy, official website.
https://www.genesisenergy.co.nz/
Used for: genesisenergy.co.nz first-party domain reference.

[50] Meta Safety Center, scam prevention / tips to avoid phishing and scams.
https://www.meta.com/safety/topics/safety-basics/tools/scams/
https://www.meta.com/safety/topics/safety-basics/tools/avoid/
Used for: Meta/Facebook/Instagram brand context, urgency, fake support, investment, friend-in-need and credential/MFA requests.

[51] Amazon Web Services, "Report Suspicious Emails."
https://aws.amazon.com/security/report-suspicious-emails/
Used for: Amazon/AWS brand context, amazon.com and fake-site/credential/malware behaviour.

[52] Facebook Help Center, Advanced Protection legitimate email guidance.
https://www.facebook.com/help/1052552578831700
Used for: security@facebookmail.com / facebookmail.com as an official Facebook sender domain.

[53] Air New Zealand, official flight-booking website.
https://www.airnewzealand.co.nz/flights/en-nz/
Used for: airnewzealand.co.nz first-party domain reference.

[54] New Zealand Police, 2026 warning about police/cryptocurrency impersonation.
https://www.police.govt.nz/news/release/police-warn-scammers-impersonating-nz-police-targeting-cryptocurrency-wallet-holders
Used for: police-authority impersonation and cryptocurrency password/seed-phrase behaviour.

## Future weak-reputation sources

[55] Tranco, research-oriented top-domain ranking.
https://tranco-list.eu/
Used for: possible weak established-domain evidence.

[56] Cloudflare Radar, Domain Rankings datasets.
https://developers.cloudflare.com/radar/investigate/domain-ranking-datasets/
Used for: possible weak popularity/establishment evidence.

[57] ICANN, Registration Data Access Protocol (RDAP).
https://www.icann.org/rdap/
Used for: possible domain registration-history evidence.

[58] Chromium, HSTS Preload List information.
https://www.chromium.org/hsts/
Used for: possible weak HSTS-preload maturity signal.

[59] ICANN, DNSSEC resources.
https://www.icann.org/resources/pages/dnssec-2012-02-25-en
Used for: DNS integrity context; currently score-neutral.

## Methodology notes

- A first-party source supports the organisation/domain relationship, but does not prove that every message using that domain is safe.
- Platform domains such as Dropbox, Docusign, Facebook/Instagram, LinkedIn, SharePoint and cloud-hosting domains can carry user-controlled content. They are therefore deliberately score-neutral or reduced in positive weight.
- The wording sources support broad scam behaviours. The exact regex phrases are implementation examples and are not presented as direct quotations.
- Threat-feed data changes rapidly and should be updated separately rather than embedded permanently.
- Scoring values are implementation choices and must be calibrated against legitimate and phishing test samples.
