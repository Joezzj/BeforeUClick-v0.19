// settings/options.js
// Settings-page UI. Read-only reference summaries come from the same data files used by the checker.

const highlightModeEl = document.getElementById("highlightMode");
const clickGuardModeEl = document.getElementById("clickGuardMode");
const linkInfoModeEl = document.getElementById("linkInfoMode");
const fontSizeEl = document.getElementById("fontSize");
const densityEl = document.getElementById("density");
const highContrastEl = document.getElementById("highContrast");
const reducedMotionEl = document.getElementById("reducedMotion");
const inboxPreviewModeEl = document.getElementById("inboxPreviewMode");
const knownSenderListEl = document.getElementById("knownSenderList");
const knownEmptyEl = document.getElementById("knownEmpty");
const addKnownSenderForm = document.getElementById("addKnownSenderForm");
const addKnownSenderInput = document.getElementById("addKnownSenderInput");
const saveStatusEl = document.getElementById("saveStatus");

/** Renders a compact list of read-only rule/reference tags. */
function bucRenderOptionTags(containerId, items) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.textContent = "";

    items.forEach(value => {
        const tag = document.createElement("span");
        tag.className = "tag";
        tag.textContent = value;
        container.appendChild(tag);
    });
}

/** Returns a short readable domain summary for an organisation reference. */
function bucOrganisationOptionLabel(item) {
    const firstRule = item.domainRules?.[0];
    const domain = firstRule?.domain || item.officialDomains?.[0] || item.officialShortDomains?.[0] || "reference";
    return `${item.name} — ${domain}`;
}

/** Refreshes all read-only rule counts from the shared Reference Dataset v1.0 files. */
function bucRenderReferenceSummary() {
    document.getElementById("organisationCount").textContent = BUC_ORGANISATION_REFERENCES.length;
    bucRenderOptionTags("organisationList", BUC_ORGANISATION_REFERENCES.map(bucOrganisationOptionLabel));

    document.getElementById("wordingCount").textContent = BUC_WORDING_PATTERN_GROUPS.length;
    bucRenderOptionTags(
        "wordingList",
        BUC_WORDING_PATTERN_GROUPS.map(item => `${item.name} — ${item.evidenceClass || "WORDING_WEAK"}`)
    );

    document.getElementById("namespaceCount").textContent = BUC_CONTROLLED_NAMESPACES.length;
    bucRenderOptionTags("namespaceList", BUC_CONTROLLED_NAMESPACES.map(item => item.suffix));

    document.getElementById("freemailCount").textContent = BUC_FREEMAIL_DOMAINS.length;
    bucRenderOptionTags("freemailList", BUC_FREEMAIL_DOMAINS);

    document.getElementById("threatCount").textContent = BUC_THREAT_SOURCE_DEFINITIONS.length;
    bucRenderOptionTags(
        "threatList",
        BUC_THREAT_SOURCE_DEFINITIONS.map(item => `${item.name} — ${item.evidenceClass} (${item.integrationStatus})`)
    );

    const evidenceEntries = Object.entries(BUC_REFERENCE_EVIDENCE_CLASSES);
    document.getElementById("evidenceCount").textContent = evidenceEntries.length;
    bucRenderOptionTags(
        "evidenceList",
        evidenceEntries.map(([key, value]) => {
            const points = Number(value.suggestedPoints) || 0;
            const signed = points > 0 ? `+${points}` : String(points);
            return `${key} — ${signed} (${value.affectsScore ? "score" : "context"})`;
        })
    );

    document.getElementById("reputationCount").textContent = BUC_REPUTATION_SOURCE_DEFINITIONS.length;
    bucRenderOptionTags(
        "reputationList",
        BUC_REPUTATION_SOURCE_DEFINITIONS.map(item => `${item.name} — ${item.evidenceClass} (${item.integrationStatus})`)
    );
}

/** Renders the locally-saved known-sender list. */
function bucRenderKnownSenders(preferences) {
    const senders = preferences.knownSenders || [];
    knownSenderListEl.textContent = "";
    knownEmptyEl.classList.toggle("hidden", senders.length > 0);

    senders.forEach(email => {
        const row = document.createElement("li");
        row.className = "entry-row";

        const label = document.createElement("span");
        label.className = "entry-email";
        label.textContent = email;

        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "entry-remove";
        remove.textContent = "Remove";
        remove.addEventListener("click", async () => {
            const updated = await bucRemoveKnownSender(email);
            bucRenderKnownSenders(updated);
            bucShowSaved("Known sender removed.");
        });

        row.append(label, remove);
        knownSenderListEl.appendChild(row);
    });
}

/** Shows a short non-blocking save confirmation. */
function bucShowSaved(message) {
    saveStatusEl.textContent = message;
    clearTimeout(bucShowSaved.timer);
    bucShowSaved.timer = setTimeout(() => { saveStatusEl.textContent = ""; }, 1800);
}

/** Persists the current link-behaviour controls. */
async function bucSaveBehaviourSettings() {
    const current = await bucGetPreferences();
    current.highlightMode = highlightModeEl.value;
    current.clickGuardMode = clickGuardModeEl.value;
    current.linkInfoMode = linkInfoModeEl.value;
    current.fontSize = fontSizeEl.value;
    current.density = densityEl.value;
    current.highContrast = highContrastEl.checked;
    current.reducedMotion = reducedMotionEl.checked;
    current.inboxPreviewMode = inboxPreviewModeEl.value;
    const saved = await bucSavePreferences(current);
    bucApplyExtensionPagePreferences(saved);
    bucShowSaved("Settings saved. They apply on the next email check.");
}

highlightModeEl.addEventListener("change", bucSaveBehaviourSettings);
clickGuardModeEl.addEventListener("change", bucSaveBehaviourSettings);
linkInfoModeEl.addEventListener("change", bucSaveBehaviourSettings);
fontSizeEl.addEventListener("change", bucSaveBehaviourSettings);
densityEl.addEventListener("change", bucSaveBehaviourSettings);
highContrastEl.addEventListener("change", bucSaveBehaviourSettings);
reducedMotionEl.addEventListener("change", bucSaveBehaviourSettings);
inboxPreviewModeEl.addEventListener("change", bucSaveBehaviourSettings);

addKnownSenderForm.addEventListener("submit", async event => {
    event.preventDefault();
    const email = addKnownSenderInput.value.trim().toLowerCase();
    if (!email) return;

    const updated = await bucAddKnownSender(email);
    addKnownSenderInput.value = "";
    bucRenderKnownSenders(updated);
    bucShowSaved("Known sender added.");
});

(async function initialiseOptions() {
    bucRenderReferenceSummary();
    const preferences = await bucGetPreferences();
    highlightModeEl.value = preferences.highlightMode;
    clickGuardModeEl.value = preferences.clickGuardMode;
    linkInfoModeEl.value = preferences.linkInfoMode;
    fontSizeEl.value = preferences.fontSize;
    densityEl.value = preferences.density;
    highContrastEl.checked = preferences.highContrast;
    reducedMotionEl.checked = preferences.reducedMotion;
    inboxPreviewModeEl.value = preferences.inboxPreviewMode;
    bucApplyExtensionPagePreferences(preferences);
    bucRenderKnownSenders(preferences);
})();
