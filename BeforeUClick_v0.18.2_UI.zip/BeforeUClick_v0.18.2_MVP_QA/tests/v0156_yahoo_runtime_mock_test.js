const fs = require("fs");
const path = require("path");
const vm = require("vm");
const rootDir = path.resolve(__dirname, "..");

class FakeElement {
    constructor(name, options = {}) {
        this.name = name;
        this.innerText = options.text || "";
        this.textContent = this.innerText;
        this.className = options.className || "";
        this.attrs = { ...(options.attrs || {}) };
        this.selectorMap = new Map();
        this.closestMap = new Map();
        this.parentElement = options.parent || null;
        this.children = [];
        this.rect = options.rect || { top: 100, left: 100, width: 500, height: 80, right: 600, bottom: 180 };
        this.removed = false;
    }

    set(selector, elements) {
        this.selectorMap.set(selector, Array.isArray(elements) ? elements : [elements]);
        return this;
    }

    setClosest(selector, element) {
        this.closestMap.set(selector, element);
        return this;
    }

    querySelectorAll(selector) {
        return this.selectorMap.get(selector) || [];
    }

    querySelector(selector) {
        return this.querySelectorAll(selector)[0] || null;
    }

    closest(selector) {
        if (this.closestMap.has(selector)) return this.closestMap.get(selector);
        return null;
    }

    matches(selector) {
        if (selector.includes("[contenteditable='true']") && this.attrs.contenteditable === "true") return true;
        if (selector.includes("[role='textbox']") && this.attrs.role === "textbox") return true;
        return false;
    }

    contains(element) {
        return element === this || this.children.includes(element);
    }

    getAttribute(name) {
        return this.attrs[name] ?? null;
    }

    getBoundingClientRect() {
        return this.rect;
    }

    cloneNode() {
        const clone = new FakeElement(`${this.name}-clone`, {
            text: this.innerText,
            attrs: this.attrs,
            rect: this.rect
        });
        // Quoted-history selectors return nothing in this runtime unit test.
        return clone;
    }

    remove() {
        this.removed = true;
    }

    querySelectorAllCombinedFallback() {
        return [];
    }
}

global.Element = FakeElement;
global.window = {
    innerHeight: 900,
    innerWidth: 1440,
    getComputedStyle() {
        return { display: "block", visibility: "visible", opacity: "1" };
    }
};

const documentSelectorMap = new Map();
global.document = {
    addEventListener() {},
    querySelectorAll(selector) {
        return documentSelectorMap.get(selector) || [];
    },
    contains(element) {
        return element instanceof FakeElement && !element.removed;
    }
};

function load(file) {
    vm.runInThisContext(
        fs.readFileSync(path.join(rootDir, file), "utf8"),
        { filename: file }
    );
}

load("adapters/shared/dom.js");
load("adapters/shared/links.js");
load("adapters/yahoo/extraction.js");
load("adapters/yahoo/links.js");

const root = new FakeElement("message-card", { text: "Header and message" });
const main = new FakeElement("main", { text: "Main" });
const article = root;

const composeEditor = new FakeElement("compose-editor", {
    text: "Draft body",
    attrs: { contenteditable: "true", role: "textbox" },
    rect: { top: 30, left: 800, width: 400, height: 200, right: 1200, bottom: 230 }
});
const composeBody = new FakeElement("compose-body", {
    text: "Draft body that must not be selected",
    rect: { top: 30, left: 800, width: 400, height: 200, right: 1200, bottom: 230 }
});
composeBody.set("[contenteditable='true'][role='textbox'], [contenteditable='true']", composeEditor);

const sender = new FakeElement("sender", {
    text: "Yahoo Test",
    attrs: {
        "data-email-address": "alerts@yahoo-example.test",
        "aria-label": "From: Yahoo Test alerts@yahoo-example.test"
    }
});
const to = new FakeElement("to", {
    text: "To: student@example.net",
    attrs: { "aria-label": "To: student@example.net" }
});
const cc = new FakeElement("cc", {
    text: "Cc: tutor@example.org",
    attrs: { "aria-label": "Cc: tutor@example.org" }
});
const subject = new FakeElement("subject", { text: "Yahoo adapter test message" });
const date = new FakeElement("date", { text: "11 September 2026, 8:45 AM" });

const anchor = new FakeElement("anchor", {
    text: "Review account",
    attrs: {
        href: "https://example.invalid/account",
        role: "",
        style: "",
        class: ""
    },
    rect: { top: 260, left: 150, width: 120, height: 20, right: 270, bottom: 280 }
});
anchor.href = "https://example.invalid/account";
anchor.querySelectorAll = function(selector) {
    if (selector === "img") return [];
    return [];
};
anchor.querySelector = function() { return null; };
anchor.closest = function(selector) {
    if (selector === "[data-test-id='message-card']") return root;
    if (selector === "[role='article']") return article;
    if (selector === "[role='main']") return main;
    return null;
};

const readBody = new FakeElement("read-body", {
    text: "This is the current Yahoo message body. Review account.",
    rect: { top: 220, left: 100, width: 650, height: 300, right: 750, bottom: 520 }
});
readBody.parentElement = root;
readBody.setClosest("[data-test-id='message-card']", root);
readBody.setClosest("[role='article']", article);
readBody.setClosest("[role='main']", main);
readBody.querySelector = function(selector) {
    if (selector === "a[href]") return anchor;
    return FakeElement.prototype.querySelector.call(this, selector);
};
readBody.querySelectorAll = function(selector) {
    if (selector === "a[href]") return [anchor];
    return this.selectorMap.get(selector) || [];
};
readBody.cloneNode = function() {
    const clone = new FakeElement("read-body-clone", {
        text: "This is the current Yahoo message body. Review account."
    });
    clone.querySelectorAll = () => [];
    return clone;
};

root.set("[data-test-id='message-from']", sender);
root.set("[data-test-id='message-to']", to);
root.set("[data-test-id='message-cc']", cc);
root.set("[data-test-id='message-subject']", subject);
root.set("[data-test-id='message-date']", date);
root.setClosest("[role='main']", main);

documentSelectorMap.set("[data-test-id='message-body']", [readBody]);
documentSelectorMap.set("[role='main'] [role='document']", [composeBody, readBody]);

const context = findCurrentYahooMessage();
if (!context) throw new Error("Yahoo current message was not found.");
if (context.body !== readBody) throw new Error("Compose body was selected instead of read message.");

const metadata = extractYahooMetadata(context);
if (metadata.sender !== "alerts@yahoo-example.test") {
    throw new Error(`Wrong sender: ${metadata.sender}`);
}
if (!metadata.recipients.to.includes("student@example.net")) {
    throw new Error(`To extraction failed: ${JSON.stringify(metadata.recipients.to)}`);
}
if (!metadata.recipients.cc.includes("tutor@example.org")) {
    throw new Error(`CC extraction failed: ${JSON.stringify(metadata.recipients.cc)}`);
}
if (metadata.subject !== "Yahoo adapter test message") {
    throw new Error(`Wrong subject: ${metadata.subject}`);
}
if (metadata.date !== "11 September 2026, 8:45 AM") {
    throw new Error(`Wrong date: ${metadata.date}`);
}

const text = extractYahooMessageText(context);
if (!text.includes("current Yahoo message body")) {
    throw new Error(`Body extraction failed: ${text}`);
}

const links = extractYahooLinks(context);
if (links.length !== 1 || links[0].url !== "https://example.invalid/account") {
    throw new Error(`Yahoo link extraction failed: ${JSON.stringify(links)}`);
}

console.log("v0.15.6 Yahoo runtime mock test: PASS");
console.log(JSON.stringify({
    selectedReadMessage: true,
    composeRejected: true,
    sender: metadata.sender,
    to: metadata.recipients.to,
    cc: metadata.recipients.cc,
    subject: metadata.subject,
    date: metadata.date,
    links: links.map(link => link.url)
}, null, 2));
