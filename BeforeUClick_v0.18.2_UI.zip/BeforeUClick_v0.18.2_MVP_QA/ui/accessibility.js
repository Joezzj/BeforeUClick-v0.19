// ui/accessibility.js
// Small local UI preference bridge for injected BeforeUClick controls.

let bucCurrentUiPreferences = {
    fontSize: "normal",
    density: "comfortable",
    highContrast: false,
    reducedMotion: false,
    linkInfoMode: "hover-focus"
};

/** Stores the current local UI preferences for injected panels/popovers. */
function bucSetUiPreferences(preferences) {
    bucCurrentUiPreferences = {
        ...bucCurrentUiPreferences,
        ...(preferences || {})
    };
}

/** Scales an injected UI pixel size based on the user's local font-size preference. */
function bucUiPx(base) {
    const scale = bucCurrentUiPreferences.fontSize === "xlarge"
        ? 1.28
        : bucCurrentUiPreferences.fontSize === "large"
            ? 1.14
            : 1;
    return Math.round(Number(base || 0) * scale);
}

/** Applies accessibility data to one injected BeforeUClick root. */
function bucApplyInjectedUiPreferences(element) {
    if (!element) return;
    element.dataset.bucFontSize = bucCurrentUiPreferences.fontSize || "normal";
    element.dataset.bucDensity = bucCurrentUiPreferences.density || "comfortable";
    element.dataset.bucHighContrast = bucCurrentUiPreferences.highContrast ? "true" : "false";
    element.dataset.bucReducedMotion = bucCurrentUiPreferences.reducedMotion ? "true" : "false";
}
