# BeforeUClick v0.13 Tests

Run the local reference/scoring smoke test from the project root:

```text
node tests/reference_smoke_test.js
```

The test checks:

- Reference Dataset v1.0 loads correctly.
- `microsoft.com` can provide first-party reassurance.
- `sharepoint.com` and `dropbox.com` are recognised but remain destination-score-neutral because they can host tenant/user content.
- `govt.nz` moderated namespace recognition.
- wording evidence classes and the wording cap.
- official-sender negative scoring.
- brand-on-free-mail sender warnings.
- displayed-link/destination mismatch.
- neutral score baseline of 15.

These are smoke tests, not the final Capstone accuracy/false-positive evaluation.


## v0.14 additions

In addition to `reference_smoke_test.js`, v0.14 should be live-tested on:
- Gmail;
- Outlook / Hotmail / Microsoft 365 Web;
- Yahoo Mail Web.

The Outlook/Yahoo adapters are explicitly experimental until their current live DOMs have been
validated. Treat unavailable metadata as a pass condition when the field cannot be associated
safely; cross-message guessing is not acceptable.


## v0.15 progressive-disclosure test

`v015_ui_smoke_test.js` checks that crowded fields have left the normal popup while the full report preserves the technical inspection sections.

## v0.18.1 MVP Panel Candidate

`v0181_mvp_panel_candidate_test.js` checks the five-state assessment model, component/coverage rules, weak-evidence caps, hidden ordinary-user score, three-provider MVP modules and presentation-oriented regression requirements.
