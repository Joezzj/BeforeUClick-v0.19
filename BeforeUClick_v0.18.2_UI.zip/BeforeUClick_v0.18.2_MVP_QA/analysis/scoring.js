// analysis/scoring.js
// Evidence-weighted scoring engine with Reference Dataset v1.0.
// The score is an internal decision-support indicator, not a probability that an email is malicious.

const BUC_SCORING_MODEL = Object.freeze({
    baseUncertaintyScore: 15,
    identityCap: 30,
    linkCap: 45,
    wordingCap: 15,
    combinationCap: 20,
    weakIdentityCap: 8,
    weakLinkCap: 8,
    weakWordingCap: 6,
    reassuranceCap: 15,
    reassuranceCapWhenStrongConcern: 5,
    totalCap: 100,
    criticalMinimum: 70,
    thresholds: Object.freeze({
        noConcernsMax: 9,
        review: 20,
        caution: 35,
        high: 60
    })
});

/**
 * Returns a score-based fallback verdict. The main pipeline can refine this using the
 * actual positive/negative evidence so "unknown" is not confused with "reassuring".
 */
function bucScoreLevel(score) {
    const value = Number.isFinite(score) ? score : BUC_SCORING_MODEL.baseUncertaintyScore;

    if (value >= BUC_SCORING_MODEL.thresholds.high) {
        return { key: "high", label: "HIGH CONCERN", icon: "!", rank: 4 };
    }
    if (value >= BUC_SCORING_MODEL.thresholds.caution) {
        return { key: "caution", label: "CAUTION", icon: "⚠", rank: 3 };
    }
    if (value >= BUC_SCORING_MODEL.thresholds.review) {
        return { key: "review", label: "REVIEW", icon: "△", rank: 2 };
    }
    if (value <= BUC_SCORING_MODEL.thresholds.noConcernsMax) {
        return { key: "no-concerns", label: "NO OBVIOUS CONCERNS", icon: "✓", rank: 0 };
    }
    return { key: "unknown", label: "UNKNOWN", icon: "?", rank: 1 };
}

/**
 * Converts sender/metadata evidence into the identity-module score while preventing
 * repeated weak clues from growing without limit.
 */
function bucScoreIdentityEvidence(senderResult, metadataResult, bodyIdentityResult) {
    const allEvidence = [
        ...(senderResult?.evidence || []),
        ...(metadataResult?.evidence || []),
        ...(bodyIdentityResult?.evidence || [])
    ];
    const evidence = allEvidence.filter(item => (Number(item.points) || 0) > 0);

    const weak = evidence.filter(item => (item.strength || "weak") === "weak");
    const stronger = evidence.filter(item => (item.strength || "weak") !== "weak");
    const weakRaw = weak.reduce((total, item) => total + Math.max(0, Number(item.points) || 0), 0);
    const strongerRaw = stronger.reduce((total, item) => total + Math.max(0, Number(item.points) || 0), 0);
    const weakApplied = Math.min(weakRaw, BUC_SCORING_MODEL.weakIdentityCap);
    const raw = weakRaw + strongerRaw;

    return {
        score: Math.min(weakApplied + strongerRaw, BUC_SCORING_MODEL.identityCap),
        rawScore: raw,
        weakRaw,
        weakApplied,
        evidence,
        allEvidence
    };
}

/**
 * Adds the exact link context to a warning so score evidence can point back to the
 * specific URL/button/image that caused it.
 */
function bucAttachLinkContext(warning, link) {
    return {
        ...warning,
        points: Number(warning.points ?? warning.score) || 0,
        category: warning.category || "link",
        source: warning.source || "link",
        linkId: link.id || null,
        linkUrl: link.url || "",
        displayedText: link.text || link.altText || "",
        linkType: link.type || "link",
        registrableDomain: link.domain?.registrableDomain || link.domain?.hostname || ""
    };
}

/**
 * Scores link evidence using the highest-risk destination as the main contribution.
 * A small multi-link bonus is allowed, but harmless links never average-down a dangerous one.
 */
function bucScoreLinkEvidence(links) {
    const scoredLinks = (links || [])
        .map(link => ({
            link,
            id: link.id || null,
            score: Math.max(0, Number(link.score) || 0),
            warnings: link.warningDetails || []
        }))
        .sort((a, b) => b.score - a.score);

    const highest = scoredLinks[0]?.score || 0;
    const additionalSuspicious = Math.max(
        0,
        scoredLinks.filter(item => item.score >= 10).length - (highest >= 10 ? 1 : 0)
    );
    const multiLinkBonus = Math.min(additionalSuspicious * 2, 5);

    const evidence = scoredLinks.flatMap(item =>
        item.warnings.map(warning => bucAttachLinkContext(warning, item.link))
    );

    return {
        score: Math.min(highest + multiLinkBonus, BUC_SCORING_MODEL.linkCap),
        highestLinkScore: highest,
        multiLinkBonus,
        suspiciousLinkCount: scoredLinks.filter(item => item.score >= 10).length,
        evidence
    };
}

/**
 * Scores wording categories separately from technical evidence and deliberately caps their influence.
 */
function bucScoreWordingEvidence(wordingResult) {
    const matches = wordingResult?.matches || [];
    const weak = matches.filter(match => (match.strength || "weak") === "weak");
    const stronger = matches.filter(match => (match.strength || "weak") !== "weak");
    const weakRaw = weak.reduce((total, match) => total + (Number(match.score) || 0), 0);
    const strongerRaw = stronger.reduce((total, match) => total + (Number(match.score) || 0), 0);
    const weakApplied = Math.min(weakRaw, BUC_SCORING_MODEL.weakWordingCap);
    const raw = weakRaw + strongerRaw;

    return {
        score: Math.min(weakApplied + strongerRaw, BUC_SCORING_MODEL.wordingCap),
        rawScore: raw,
        weakRaw,
        weakApplied,
        evidence: matches.map(match => ({
            code: match.id,
            category: "wording",
            source: "wording",
            strength: match.strength || "weak",
            evidenceClass: match.evidenceClass || "WORDING_WEAK",
            points: Number(match.score) || 0,
            text: match.label,
            matchedPhrases: match.matchedPhrases || []
        }))
    };
}

/**
 * Returns all negative-point evidence already emitted by sender/metadata modules.
 * These observations are kept out of the concern score and applied only through the capped
 * reassurance stage.
 */
function bucCollectModuleReassuringEvidence(senderResult, metadataResult) {
    return [
        ...(senderResult?.evidence || []),
        ...(metadataResult?.evidence || [])
    ].filter(item => (Number(item.points) || 0) < 0);
}

/**
 * Builds link-based reassuring evidence from recognised official destinations and controlled
 * namespaces. Repeated links to the same organisation/namespace count once.
 */
function bucBuildLinkReassuringEvidence(links) {
    const evidence = [];
    const seenOrganisations = new Set();
    const seenShortLinks = new Set();
    const seenNamespaces = new Set();

    (links || []).forEach(link => {
        const reference = link.reference || {};
        const official = reference.officialOrganisation;
        if (official?.id && !seenOrganisations.has(official.id)) {
            seenOrganisations.add(official.id);
            evidence.push({
                code: "official-domain-reference",
                evidenceClass: "OFFICIAL_DESTINATION",
                category: "reassuring",
                source: "organisation-reference",
                strength: "positive",
                points: bucEvidenceClassPoints("OFFICIAL_DESTINATION", -4),
                text: `Destination matches a sourced first-party domain for ${official.name}.`,
                linkId: link.id || null,
                linkUrl: link.url || "",
                displayedText: link.text || link.altText || "",
                registrableDomain: link.domain?.registrableDomain || link.domain?.hostname || "",
                organisation: official.name,
                references: official.references || []
            });
        }

        const shortLink = reference.shortLinkOrganisation;
        const shortDomain = reference.primaryRule?.domain;
        if (shortLink?.id && shortDomain && !seenShortLinks.has(shortDomain)) {
            seenShortLinks.add(shortDomain);
            evidence.push({
                code: "official-short-link-reference",
                evidenceClass: "OFFICIAL_SHORT_LINK",
                category: "reassuring",
                source: "organisation-reference",
                strength: "positive",
                points: bucEvidenceClassPoints("OFFICIAL_SHORT_LINK", -1),
                text: `Destination uses a sourced ${shortLink.name} short-link domain. The final destination should still be checked.`,
                linkId: link.id || null,
                linkUrl: link.url || "",
                displayedText: link.text || link.altText || "",
                registrableDomain: link.domain?.registrableDomain || link.domain?.hostname || "",
                organisation: shortLink.name,
                references: shortLink.references || []
            });
        }

        const controlled = reference.controlledNamespace;
        const suffix = controlled?.suffix;
        if (suffix && controlled.affectsScore !== false && !seenNamespaces.has(suffix)) {
            seenNamespaces.add(suffix);
            const key = controlled.scoreKey || "CONTROLLED_NAMESPACE";
            evidence.push({
                code: "controlled-namespace-reference",
                evidenceClass: key,
                category: "reassuring",
                source: "namespace-reference",
                strength: "positive",
                points: bucEvidenceClassPoints(key, -2),
                text: `Destination is within the sourced controlled namespace ${suffix}.`,
                linkId: link.id || null,
                linkUrl: link.url || "",
                displayedText: link.text || link.altText || "",
                registrableDomain: link.domain?.registrableDomain || link.domain?.hostname || "",
                namespace: suffix,
                references: controlled.references || []
            });
        }
    });

    return evidence;
}

/**
 * Builds the complete positive-evidence list. "No warning" never creates a deduction;
 * every negative point must correspond to a concrete reason that can be displayed to the user.
 */
function bucBuildReassuringEvidence({ senderResult, metadataResult, links }) {
    return [
        ...bucCollectModuleReassuringEvidence(senderResult, metadataResult),
        ...bucBuildLinkReassuringEvidence(links)
    ];
}

/**
 * Applies reassuring evidence with hard safety caps.
 * - normal email: up to -15
 * - strong concern present: at most -5
 * - critical threat evidence: no reassurance deduction at all
 *
 * Unlike earlier builds, a positive observation can now reduce an otherwise-unknown email even when
 * unrelated destinations remain unknown. Unknown links simply contribute zero; they do not
 * erase verified positive evidence.
 */
function bucScoreReassuringEvidence({ senderResult, metadataResult, links, hasStrongConcern, hasCriticalEvidence }) {
    const requestedEvidence = bucBuildReassuringEvidence({ senderResult, metadataResult, links });
    const requestedReduction = Math.abs(
        requestedEvidence.reduce((total, item) => total + Math.min(0, Number(item.points) || 0), 0)
    );

    const cap = hasCriticalEvidence
        ? 0
        : (hasStrongConcern
            ? BUC_SCORING_MODEL.reassuranceCapWhenStrongConcern
            : BUC_SCORING_MODEL.reassuranceCap);
    const appliedReduction = Math.min(requestedReduction, cap);

    let remaining = appliedReduction;
    const evidence = requestedEvidence.map(item => {
        const requested = Math.abs(Math.min(0, Number(item.points) || 0));
        const applied = Math.min(requested, remaining);
        remaining -= applied;
        return {
            ...item,
            requestedPoints: -requested,
            points: -applied,
            capped: applied < requested,
            notAppliedReason: applied < requested
                ? (hasCriticalEvidence
                    ? "Critical threat evidence prevents reassuring deductions from reducing this result."
                    : "The reassuring adjustment reached the current safety cap.")
                : ""
        };
    });

    const destinationLinks = (links || []).filter(link => link.url && link.domain);
    const recognisedDestinations = destinationLinks.filter(link =>
        Boolean(link.reference?.officialOrganisation || link.reference?.shortLinkOrganisation || (link.reference?.controlledNamespace?.affectsScore !== false && link.reference?.controlledNamespace))
    );

    return {
        score: -appliedReduction,
        requestedReduction,
        appliedReduction,
        cap,
        recognisedDestinationCount: recognisedDestinations.length,
        destinationCount: destinationLinks.length,
        evidence
    };
}

/**
 * Finds whether any analysed link contains a warning matching the supplied code/strength criteria.
 */
function bucLinkHasEvidence(links, { code = null, strength = null } = {}) {
    return (links || []).some(link =>
        (link.warningDetails || []).some(warning => {
            if (code && warning.code !== code) return false;
            if (strength && warning.strength !== strength) return false;
            return true;
        })
    );
}

/**
 * Builds cross-signal evidence when independent modules reinforce each other.
 * These bonuses are intentionally limited so one repeated theme cannot dominate the whole result.
 */
function bucBuildCombinationEvidence({ senderResult, metadataResult, bodyIdentityResult, wordingResult, links }) {
    const combinations = [];
    const wordingIds = new Set((wordingResult?.matches || []).map(match => match.id));
    const identityEvidence = [
        ...(senderResult?.evidence || []),
        ...(metadataResult?.evidence || []),
        ...(bodyIdentityResult?.evidence || [])
    ];

    const hasIdentityMismatch = identityEvidence.some(item =>
        ["medium", "strong", "critical"].includes(item.strength)
    );
    const hasStrongLink = bucLinkHasEvidence(links, { strength: "strong" }) ||
        bucLinkHasEvidence(links, { strength: "critical" });
    const hasBrandMismatch = bucLinkHasEvidence(links, { code: "brand-domain-inconsistency" });
    const hasCredentialRequest = wordingIds.has("credential-request");
    const hasUrgency = wordingIds.has("urgency");
    const hasSensitiveAction = hasCredentialRequest ||
        wordingIds.has("account-threat") ||
        wordingIds.has("payment-pressure");

    if (hasCredentialRequest && hasStrongLink) {
        combinations.push({
            code: "credential-plus-strong-link",
            category: "combination",
            source: "cross-signal",
            strength: "strong",
            points: 10,
            text: "Credential/account verification wording appears together with a strong suspicious-link indicator."
        });
    }

    if (hasIdentityMismatch && hasStrongLink) {
        combinations.push({
            code: "identity-plus-strong-link",
            category: "combination",
            source: "cross-signal",
            strength: "strong",
            points: 8,
            text: "Sender/metadata inconsistency appears together with a strong suspicious-link indicator."
        });
    }

    if (hasUrgency && hasSensitiveAction && hasStrongLink) {
        combinations.push({
            code: "urgency-action-link",
            category: "combination",
            source: "cross-signal",
            strength: "medium",
            points: 5,
            text: "Urgency, a sensitive requested action and a suspicious link appear together."
        });
    }

    if (hasBrandMismatch && hasIdentityMismatch) {
        combinations.push({
            code: "brand-plus-identity",
            category: "combination",
            source: "cross-signal",
            strength: "strong",
            points: 7,
            text: "The claimed organisation does not match the destination and the message also contains sender/metadata inconsistency."
        });
    }

    return combinations;
}

/**
 * Builds the user-facing verdict using both score and evidence direction. This is what separates
 * "we found nothing" from "we positively recognised reassuring evidence".
 */
function bucBuildOverallVerdict({ score, reassuranceApplied, hasCriticalEvidence, hasStrongConcern, hasMediumConcern }) {
    if (hasCriticalEvidence || score >= BUC_SCORING_MODEL.thresholds.high) {
        return { key: "high", label: "HIGH CONCERN", icon: "!", rank: 4 };
    }
    if (hasStrongConcern || score >= BUC_SCORING_MODEL.thresholds.caution) {
        return { key: "caution", label: "CAUTION", icon: "⚠", rank: 3 };
    }
    if (hasMediumConcern || score >= BUC_SCORING_MODEL.thresholds.review) {
        return { key: "review", label: "REVIEW", icon: "△", rank: 2 };
    }
    if (score <= BUC_SCORING_MODEL.thresholds.noConcernsMax && reassuranceApplied > 0) {
        return { key: "no-concerns", label: "NO OBVIOUS CONCERNS", icon: "✓", rank: 0 };
    }
    return { key: "unknown", label: "UNKNOWN", icon: "?", rank: 1 };
}

/**
 * Produces the complete internal score, including the neutral baseline, concerning evidence,
 * capped reassuring evidence, exact link references and a non-probabilistic verdict.
 */
function scoreBeforeUClickEvidence({ senderResult, metadataResult, bodyIdentityResult, wordingResult, links }) {
    const identity = bucScoreIdentityEvidence(senderResult, metadataResult, bodyIdentityResult);
    const link = bucScoreLinkEvidence(links);
    const wording = bucScoreWordingEvidence(wordingResult);
    const combinationEvidence = bucBuildCombinationEvidence({
        senderResult,
        metadataResult,
        bodyIdentityResult,
        wordingResult,
        links
    });
    const combinationRaw = combinationEvidence.reduce(
        (total, item) => total + Math.max(0, Number(item.points) || 0),
        0
    );
    const combinations = {
        score: Math.min(combinationRaw, BUC_SCORING_MODEL.combinationCap),
        rawScore: combinationRaw,
        evidence: combinationEvidence
    };

    const concerningEvidence = [
        ...identity.evidence,
        ...link.evidence,
        ...wording.evidence,
        ...combinations.evidence
    ];
    const hasCriticalEvidence = concerningEvidence.some(item => item.strength === "critical");
    const hasStrongConcern = concerningEvidence.some(item => item.strength === "strong");
    const hasMediumConcern = concerningEvidence.some(item => item.strength === "medium");

    const reassurance = bucScoreReassuringEvidence({
        senderResult,
        metadataResult,
        links,
        hasStrongConcern,
        hasCriticalEvidence
    });
    const concernScore = identity.score + link.score + wording.score + combinations.score;
    const rawScore = BUC_SCORING_MODEL.baseUncertaintyScore + concernScore + reassurance.score;
    const minimum = hasCriticalEvidence ? BUC_SCORING_MODEL.criticalMinimum : 0;
    const score = Math.min(
        Math.max(rawScore, minimum),
        BUC_SCORING_MODEL.totalCap
    );
    const verdict = bucBuildOverallVerdict({
        score,
        reassuranceApplied: reassurance.appliedReduction,
        hasCriticalEvidence,
        hasStrongConcern,
        hasMediumConcern
    });

    return {
        score: Math.round(score),
        level: verdict,
        baseScore: BUC_SCORING_MODEL.baseUncertaintyScore,
        concernScore,
        reassuranceAdjustment: reassurance.score,
        reassuranceRequested: reassurance.requestedReduction,
        reassuranceCapApplied: reassurance.cap,
        moduleScores: {
            baseline: BUC_SCORING_MODEL.baseUncertaintyScore,
            identity: identity.score,
            links: link.score,
            wording: wording.score,
            combinations: combinations.score,
            reassurance: reassurance.score,
            weakIdentityApplied: identity.weakApplied || 0,
            weakWordingApplied: wording.weakApplied || 0
        },
        caps: {
            identity: BUC_SCORING_MODEL.identityCap,
            links: BUC_SCORING_MODEL.linkCap,
            wording: BUC_SCORING_MODEL.wordingCap,
            combinations: BUC_SCORING_MODEL.combinationCap,
            reassurance: reassurance.cap,
            weakIdentity: BUC_SCORING_MODEL.weakIdentityCap,
            weakLinks: BUC_SCORING_MODEL.weakLinkCap,
            weakWording: BUC_SCORING_MODEL.weakWordingCap
        },
        linkSummary: {
            highestLinkScore: link.highestLinkScore,
            multiLinkBonus: link.multiLinkBonus,
            suspiciousLinkCount: link.suspiciousLinkCount,
            recognisedDestinationCount: reassurance.recognisedDestinationCount,
            destinationCount: reassurance.destinationCount
        },
        combinationEvidence,
        reassuringEvidence: reassurance.evidence,
        concerningEvidence,
        evidence: [...concerningEvidence, ...reassurance.evidence],
        criticalOverrideApplied: hasCriticalEvidence,
        strongestConcernStrength: hasCriticalEvidence ? "critical" : hasStrongConcern ? "strong" : hasMediumConcern ? "medium" : (concerningEvidence.length ? "weak" : "context")
    };
}
