const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const s = file => fs.readFileSync(path.join(root, file), "utf8");

const manifest = JSON.parse(s("manifest.json"));
if (!["0.15.5", "0.15.6", "0.15.7", "0.16.0", "0.18.0", "0.18.1", "0.18.2"].includes(manifest.version)) throw new Error("Unexpected Outlook-hotfix-compatible build.");
if (!manifest.content_scripts[0].matches.includes("https://outlook.cloud.microsoft/*")) {
    throw new Error("outlook.cloud.microsoft host match missing.");
}

const router = s("adapters/provider_router.js");
if (!router.includes('"outlook.cloud.microsoft"')) throw new Error("Router host missing.");

const outlook = s("adapters/outlook/extraction.js");
[
    "bucOutlookBodyCandidates",
    "\"[role='document']\"",
    "bucOutlookLooksLikeCompose",
    "candidateCount",
    "[data-testid*='message' i][data-testid*='body' i]",
    "[aria-label*='from:' i][aria-label*='@']",
    "[role='main'] [role='heading'][aria-level='2']"
].forEach(value => {
    if (!outlook.includes(value)) throw new Error(`Outlook hotfix missing: ${value}`);
});

console.log("v0.15.5 Outlook hotfix smoke test: PASS");
