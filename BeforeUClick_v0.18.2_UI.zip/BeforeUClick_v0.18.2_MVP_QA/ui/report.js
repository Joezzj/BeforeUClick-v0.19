// ui/report.js
// Webmail report UI for the current BeforeUClick MVP: concise decision panel plus link controls.

/** Maps a numeric score to the shared scoring-engine level label, with a safe fallback. */
function bucRiskLevel(score) {
    if (typeof bucScoreLevel === "function") return bucScoreLevel(score);
    if (score >= 60) return { key: "high", label: "HIGH CONCERN", icon: "!", rank: 4 };
    if (score >= 35) return { key: "caution", label: "CAUTION", icon: "⚠", rank: 3 };
    if (score >= 20) return { key: "review", label: "REVIEW", icon: "△", rank: 2 };
    if (score <= 9) return { key: "no-concerns", label: "NO OBVIOUS CONCERNS", icon: "✓", rank: 0 };
    return { key: "unknown", label: "UNKNOWN", icon: "?", rank: 1 };
}

/** Creates a DOM element using textContent rather than inserting untrusted email HTML. */
function bucCreateElement(tag, options = {}) {
    const element = document.createElement(tag);
    if (options.className) element.className = options.className;
    if (options.text != null) element.textContent = String(options.text);
    if (options.title) element.title = options.title;
    return element;
}

/** Applies the base size/position/appearance used by the floating webmail report panel. */
function bucApplyPanelStyle(panel) {
    Object.assign(panel.style, {
        position: "fixed",
        top: "76px",
        left: "20px",
        width: "420px",
        maxWidth: "calc(100vw - 40px)",
        maxHeight: "82vh",
        overflow: "hidden",
        background: "#ffffff",
        color: "#202124",
        border: "1px solid #dadce0",
        borderRadius: "12px",
        fontFamily: "Arial, Helvetica, sans-serif",
        fontSize: `${typeof bucUiPx === "function" ? bucUiPx(14) : 14}px`,
        zIndex: "2147483646",
        boxShadow: "0 8px 28px rgba(60,64,67,.30)"
    });
    if (typeof bucApplyInjectedUiPreferences === "function") bucApplyInjectedUiPreferences(panel);
    if (typeof bucCurrentUiPreferences !== "undefined" && bucCurrentUiPreferences.highContrast) panel.style.borderWidth = "2px";
}

/** Places a newly created report panel at the default on-screen location. */
function bucPlacePanelAtDefault(panel) {
    const width = Math.min(420, Math.max(280, window.innerWidth - 40));
    panel.style.width = `${width}px`;
    panel.style.left = `${Math.max(12, window.innerWidth - width - 20)}px`;
    panel.style.top = `${Math.min(76, Math.max(12, window.innerHeight - 100))}px`;
}

/** Creates the fixed webmail-side manual “Check this email” trigger. */
function createManualTrigger(onClick) {
    let button = document.getElementById("beforeuclick-check-button");
    if (button) return button;

    button = bucCreateElement("button");
    button.id = "beforeuclick-check-button";
    button.type = "button";
    button.setAttribute("aria-label", "Check this email with BeforeUClick");

    const buttonLogo = document.createElement("img");
    buttonLogo.src = chrome.runtime.getURL("icons/icon16.png");
    buttonLogo.alt = "";
    buttonLogo.style.width = "18px";
    buttonLogo.style.height = "18px";
    buttonLogo.style.objectFit = "contain";

    const buttonText = document.createElement("span");
    buttonText.textContent = "Check this email";
    button.append(buttonLogo, buttonText);

    Object.assign(button.style, {
        position: "fixed",
        right: "22px",
        bottom: "22px",
        zIndex: "2147483645",
        border: "0",
        borderRadius: "999px",
        padding: "11px 16px",
        background: "#1a73e8",
        color: "#ffffff",
        fontWeight: "600",
        fontSize: `${typeof bucUiPx === "function" ? bucUiPx(14) : 14}px`,
        cursor: "pointer",
        boxShadow: "0 4px 12px rgba(60,64,67,.35)",
        display: "flex",
        alignItems: "center",
        gap: "7px"
    });

    button.addEventListener("click", onClick);
    document.body.appendChild(button);
    return button;
}

/** Renders a short status/error panel when a full email report cannot be shown. */
function showBeforeUClickStatus(message, isError = false) {
    renderReport({
        score: 0,
        statusMessage: message,
        statusError: isError,
        metadata: {},
        unavailableChecks: [],
        warnings: [],
        links: [],
        wordingMatches: [],
        modules: {}
    });
}

/** Creates a small panel-window control button. */
function bucMakeControlButton(text, title) {
    const button = bucCreateElement("button", { text, title });
    button.type = "button";
    button.setAttribute("aria-label", title);
    Object.assign(button.style, {
        border: "0",
        background: "transparent",
        cursor: "pointer",
        fontSize: "18px",
        marginLeft: "5px",
        padding: "2px 7px",
        borderRadius: "6px",
        color: "#3c4043"
    });
    return button;
}

/** Creates a small secondary action button used inside report cards. */
function bucMakeSmallAction(text) {
    const button = bucCreateElement("button", { text });
    button.type = "button";
    Object.assign(button.style, {
        border: "1px solid #dadce0",
        background: "#ffffff",
        color: "#174ea6",
        borderRadius: "7px",
        padding: "6px 9px",
        marginTop: "8px",
        cursor: "pointer",
        fontSize: "12px",
        fontWeight: "600"
    });
    return button;
}

/** Keeps the draggable report panel within the visible browser window. */
function bucClampPanel(panel) {
    if (panel.dataset.maximised === "true") return;
    const rect = panel.getBoundingClientRect();
    const maxLeft = Math.max(8, window.innerWidth - rect.width - 8);
    const maxTop = Math.max(8, window.innerHeight - Math.min(rect.height, 80) - 8);
    panel.style.left = `${Math.min(Math.max(8, rect.left), maxLeft)}px`;
    panel.style.top = `${Math.min(Math.max(8, rect.top), maxTop)}px`;
}

/** Enables pointer-based dragging from the panel header without interfering with controls. */
function bucEnablePanelDragging(panel, header) {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    header.style.cursor = "move";
    header.style.touchAction = "none";

    header.addEventListener("pointerdown", event => {
        if (event.target.closest("button") || panel.dataset.maximised === "true") return;
        const rect = panel.getBoundingClientRect();
        dragging = true;
        offsetX = event.clientX - rect.left;
        offsetY = event.clientY - rect.top;
        header.setPointerCapture?.(event.pointerId);
        event.preventDefault();
    });

    header.addEventListener("pointermove", event => {
        if (!dragging) return;
        const rect = panel.getBoundingClientRect();
        const maxLeft = Math.max(8, window.innerWidth - rect.width - 8);
        const maxTop = Math.max(8, window.innerHeight - Math.min(rect.height, 80) - 8);
        const left = Math.min(Math.max(8, event.clientX - offsetX), maxLeft);
        const top = Math.min(Math.max(8, event.clientY - offsetY), maxTop);
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
    });

    const stop = event => {
        if (!dragging) return;
        dragging = false;
        try { header.releasePointerCapture?.(event.pointerId); } catch (_error) { /* ignored */ }
    };

    header.addEventListener("pointerup", stop);
    header.addEventListener("pointercancel", stop);
}

/** Renders the complete draggable BeforeUClick report for the latest manual analysis. */
function bucReportConcernLinks(links) {
    return (links || []).filter(link => {
        const state = typeof bucLinkHighlightState === "function" ? bucLinkHighlightState(link) : null;
        return state ? ["review", "caution", "high"].includes(state.key) : Number(link?.score || 0) >= 10;
    });
}

function bucReportTopReasons(report, limit = 3) {
    const evaluationReasons = report.evaluation?.primaryReasons || [];
    const primary = (report.scoring?.concerningEvidence || []).map(item => item.text).filter(Boolean);
    const fallback = report.warnings || [];
    return [...new Set([...evaluationReasons, ...primary, ...fallback])].slice(0, limit);
}

function bucReportDecisionText(report, concernLinks) {
    const key = (report.evaluation?.overall || report.level)?.key;
    if (key === "no-concerns") return "No obvious concerns were found in the checks that completed. This is not a safety guarantee.";
    if (key === "unknown") return "No strong warning was found, but the message remains unknown rather than verified safe.";
    if (key === "review") return "A few observations are worth reviewing before you act.";
    if (key === "high") return "Strong evidence needs your attention before you continue.";
    if (concernLinks.length === 1) return "One link needs a closer look before you continue.";
    if (concernLinks.length > 1) return `${concernLinks.length} links need a closer look before you continue.`;
    return "BeforeUClick found meaningful evidence worth checking before you act.";
}

function renderReport(report) {
    document.getElementById("beforeuclick-panel")?.remove();

    const panel = bucCreateElement("section");
    panel.id = "beforeuclick-panel";
    panel.dataset.maximised = "false";
    panel.dataset.minimised = "false";
    bucApplyPanelStyle(panel);
    panel.style.width = `${typeof bucUiPx === "function" ? bucUiPx(360) : 360}px`;
    panel.style.maxWidth = "calc(100vw - 24px)";

    const header = bucCreateElement("div");
    Object.assign(header.style, {
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "10px 10px 10px 12px", background: "#f8f9fa",
        borderBottom: "1px solid #dadce0", userSelect: "none"
    });

    const titleWrap = bucCreateElement("div");
    titleWrap.style.minWidth = "0";
    titleWrap.style.display = "flex";
    titleWrap.style.alignItems = "center";
    titleWrap.style.gap = "7px";

    const logo = document.createElement("img");
    logo.src = chrome.runtime.getURL("icons/icon48.png");
    logo.alt = "BeforeUClick";
    logo.style.width = "30px";
    logo.style.height = "30px";
    logo.style.objectFit = "contain";
    logo.style.borderRadius = "7px";

    const title = bucCreateElement("strong", { text: "BeforeUClick" });
    title.style.fontSize = "15px";

    const provider = bucCreateElement("span", {
        text: ` · ${report.provider || report.debug?.provider || "Webmail"}`
    });
    provider.style.fontSize = "11px";
    provider.style.color = "#6b7280";

    titleWrap.append(logo, title, provider);

    const controls = bucCreateElement("div");
    controls.style.flexShrink = "0";
    const minimise = bucMakeControlButton("−", "Minimise");
    const maximise = bucMakeControlButton("□", "Maximise");
    const close = bucMakeControlButton("×", "Close");
    controls.append(minimise, maximise, close);
    header.append(titleWrap, controls);

    const body = bucCreateElement("div");
    Object.assign(body.style, { padding: "12px", overflowY: "auto", maxHeight: "calc(78vh - 46px)" });

    if (report.statusMessage) {
        const status = bucCreateElement("div", { text: report.statusMessage });
        Object.assign(status.style, { padding: "11px", borderRadius: "8px", background: report.statusError ? "#fce8e6" : "#e8f0fe", color: report.statusError ? "#b3261e" : "#174ea6" });
        body.appendChild(status);
    } else {
        const level = report.evaluation?.overall || report.level || bucRiskLevel(report.score);
        const concernLinks = bucReportConcernLinks(report.links);
        const reasons = bucReportTopReasons(report);

        const summary = bucCreateElement("div");
        Object.assign(summary.style, {
            border: "1px solid #e5e7eb", borderLeft: `5px solid ${level.key === "high" ? "#b42318" : level.key === "caution" ? "#98620a" : level.key === "review" ? "#b18b00" : level.key === "no-concerns" ? "#174ea6" : "#5f6368"}`,
            borderRadius: "9px", padding: "11px", background: "#fff"
        });
        const levelText = bucCreateElement("div", { text: `${level.icon || "?"} ${level.label || "Result"}` });
        levelText.style.fontSize = "17px";
        levelText.style.fontWeight = "750";
        const decision = bucCreateElement("div", { text: bucReportDecisionText(report, concernLinks) });
        Object.assign(decision.style, { marginTop: "7px", lineHeight: "1.45", fontSize: "12px" });
        const context = bucCreateElement("div", { text: `${report.links?.length || 0} links checked${concernLinks.length ? ` · ${concernLinks.length} need attention` : ""}` });
        Object.assign(context.style, { marginTop: "7px", color: "#6b7280", fontSize: "10.5px", fontFamily: "monospace" });
        summary.append(levelText, decision, context);
        body.appendChild(summary);

        const componentValues = report.evaluation?.components || {};
        if (Object.keys(componentValues).length) {
            const componentBox = bucCreateElement("div");
            Object.assign(componentBox.style, {
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "6px",
                marginTop: "9px"
            });
            ["sender", "authentication", "links", "wording"].forEach(key => {
                const component = componentValues[key];
                if (!component?.assessment) return;
                const item = bucCreateElement("div", {
                    text: `${component.assessment.icon} ${component.label}: ${component.assessment.label.toLowerCase()}`
                });
                Object.assign(item.style, {
                    padding: "7px 8px",
                    border: "1px solid #e5e7eb",
                    borderRadius: "7px",
                    background: "#fff",
                    color: "#4b5563",
                    fontSize: "10.5px",
                    lineHeight: "1.3"
                });
                componentBox.appendChild(item);
            });
            body.appendChild(componentBox);
        }

        if (reasons.length) {
            const details = bucCreateElement("details");
            Object.assign(details.style, { marginTop: "9px", border: "1px solid #e5e7eb", borderRadius: "8px", padding: "8px 10px", background: "#fff" });
            const summaryLine = bucCreateElement("summary", { text: `${reasons.length} top ${reasons.length === 1 ? "concern" : "concerns"}` });
            Object.assign(summaryLine.style, { cursor: "pointer", fontWeight: "650", fontSize: "12px" });
            const list = bucCreateElement("ul");
            Object.assign(list.style, { paddingLeft: "18px", margin: "8px 0 2px", fontSize: "11.5px", lineHeight: "1.45" });
            reasons.forEach(reason => list.appendChild(bucCreateElement("li", { text: reason })));
            details.append(summaryLine, list);
            body.appendChild(details);
        }

        if (report.links?.length) {
            const linkBox = bucCreateElement("div");
            Object.assign(linkBox.style, { marginTop: "9px", padding: "9px 10px", borderRadius: "8px", background: "#f8f9fa", color: "#4b5563", fontSize: "11px", lineHeight: "1.4" });
            linkBox.appendChild(bucCreateElement("div", { text: "Link details now live beside the links themselves. Hover or keyboard-focus a highlighted link to inspect its destination and reasons." }));

            const actions = bucCreateElement("div");
            Object.assign(actions.style, { display: "flex", gap: "6px", flexWrap: "wrap", marginTop: "7px" });
            const showConcerns = bucMakeSmallAction("Highlight concerns");
            const showAll = bucMakeSmallAction("Show all links");
            const clear = bucMakeSmallAction("Stop checking");
            [showConcerns, showAll, clear].forEach(button => button.style.marginTop = "0");
            showConcerns.addEventListener("click", () => bucShowConcernLinks(report.links));
            showAll.addEventListener("click", () => bucShowAllCheckedLinks(report.links));
            clear.addEventListener("click", () => {
                if (typeof bucDisengageCurrentCheck === "function") {
                    bucDisengageCurrentCheck({ removePanel: true });
                }
            });
            actions.append(showConcerns, showAll, clear);
            linkBox.appendChild(actions);
            body.appendChild(linkBox);
        }

        const fullReport = bucMakeSmallAction("Inspect full report");
        Object.assign(fullReport.style, { width: "100%", marginTop: "10px", padding: "9px", fontSize: "12px", fontWeight: "700" });
        fullReport.addEventListener("click", () => {
            try { chrome.runtime.sendMessage({ type: "BUC_OPEN_FULL_REPORT" }); } catch (_error) {}
        });
        body.appendChild(fullReport);

        const note = bucCreateElement("div", { text: "Full sender, authentication, link, wording, coverage and developer diagnostics remain available in the full report." });
        Object.assign(note.style, { marginTop: "8px", color: "#6b7280", fontSize: "10.5px", lineHeight: "1.4" });
        body.appendChild(note);
    }

    let normalGeometry = null;
    minimise.addEventListener("click", () => {
        const isMinimised = panel.dataset.minimised === "true";
        panel.dataset.minimised = isMinimised ? "false" : "true";
        body.style.display = isMinimised ? "block" : "none";
        minimise.textContent = isMinimised ? "−" : "+";
        minimise.title = isMinimised ? "Minimise" : "Restore";
    });

    maximise.addEventListener("click", () => {
        const isMaximised = panel.dataset.maximised === "true";
        if (!isMaximised) {
            if (panel.dataset.minimised === "true") minimise.click();
            normalGeometry = { left: panel.style.left, top: panel.style.top, width: panel.style.width, maxWidth: panel.style.maxWidth, maxHeight: panel.style.maxHeight };
            panel.dataset.maximised = "true";
            panel.style.left = "12px";
            panel.style.top = "12px";
            panel.style.width = "calc(100vw - 24px)";
            panel.style.maxWidth = "none";
            panel.style.maxHeight = "calc(100vh - 24px)";
            body.style.maxHeight = "calc(100vh - 72px)";
            maximise.textContent = "❐";
            maximise.title = "Restore size";
        } else {
            panel.dataset.maximised = "false";
            if (normalGeometry) Object.assign(panel.style, normalGeometry);
            body.style.maxHeight = "calc(78vh - 46px)";
            maximise.textContent = "□";
            maximise.title = "Maximise";
            bucClampPanel(panel);
        }
    });

    close.addEventListener("click", () => {
        if (typeof bucDisengageCurrentCheck === "function") {
            bucDisengageCurrentCheck({ removePanel: true });
        } else {
            bucClearLinkHighlights();
            panel.remove();
        }
    });

    panel.append(header, body);
    document.body.appendChild(panel);
    bucPlacePanelAtDefault(panel);
    bucEnablePanelDragging(panel, header);
    const resizeHandler = () => {
        if (!document.contains(panel)) {
            window.removeEventListener("resize", resizeHandler);
            return;
        }
        bucClampPanel(panel);
    };
    window.addEventListener("resize", resizeHandler);
}
