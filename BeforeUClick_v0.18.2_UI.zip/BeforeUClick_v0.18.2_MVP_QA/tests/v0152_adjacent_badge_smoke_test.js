// tests/v0152_adjacent_badge_smoke_test.js
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

const highlighting = fs.readFileSync(
    path.join(root, "ui/highlighting.js"),
    "utf8"
);

[
    "position: fixed !important",
    "bucPositionLinkStatusBadge",
    "bucPositionAllLinkStatusBadges",
    "bucInstallLinkBadgePositionListeners",
    "document.body.appendChild(badge)",
    "rect.right + gap",
    "rect.left - badgeRect.width - gap"
].forEach(value => {
    if (!highlighting.includes(value)) {
        throw new Error(`Missing adjacent-badge implementation: ${value}`);
    }
});

if (highlighting.includes('anchor.insertAdjacentElement("afterend", badge)')) {
    throw new Error("Old inline badge placement is still present.");
}

console.log("v0.15.2 adjacent badge smoke test: PASS");
