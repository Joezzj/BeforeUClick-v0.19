// ui/link_popover.js
// Compact in-context link information card. Link detail lives beside the link rather than crowding the main popup.
// It only appears for links already analysed by BeforeUClick.

let bucLinkInfoMode = "hover-focus";
let bucLinkInteractionEngaged = false;
let bucLinkPopoverInstalled = false;
let bucLinkPopoverCloseTimer = null;

/** Updates the current local link-information policy. */
function bucSetLinkInfoMode(mode) {
    bucLinkInfoMode = mode === "off" ? "off" : "hover-focus";
    if (bucLinkInfoMode === "off") bucCloseLinkInfoPopover();
}

/** Enables/disables contextual link information for the current explicit manual-check session. */
function bucSetLinkInteractionEngaged(engaged) {
    bucLinkInteractionEngaged = engaged === true;
    if (!bucLinkInteractionEngaged) bucCloseLinkInfoPopover();
}

/** Removes the current information card. */
function bucCloseLinkInfoPopover() {
    clearTimeout(bucLinkPopoverCloseTimer);
    document.getElementById("beforeuclick-link-info")?.remove();
}

/** Schedules close to allow pointer movement from the link into the card. */
function bucScheduleLinkInfoClose(delay = 240) {
    clearTimeout(bucLinkPopoverCloseTimer);
    bucLinkPopoverCloseTimer = setTimeout(bucCloseLinkInfoPopover, delay);
}

/** Positions the card near the visible linked object without leaving the viewport. */
function bucPositionLinkInfoPopover(card, target) {
    const targetRect = target.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    const gap = 8;

    let left = Math.min(
        window.innerWidth - cardRect.width - 10,
        Math.max(10, targetRect.left)
    );
    let top = targetRect.bottom + gap;

    if (top + cardRect.height > window.innerHeight - 10) {
        top = Math.max(10, targetRect.top - cardRect.height - gap);
    }

    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
}

/** Requests the optional full report page for the currently analysed message. */
function bucOpenFullReportFromContent(focusLinkId = "") {
    try {
        chrome.runtime.sendMessage({ type: "BUC_OPEN_FULL_REPORT", focusLinkId });
    } catch (_error) {
        // Optional UI action must not affect analysis.
    }
}

/** Shows a small explainable information card for one analysed link. */
function bucShowLinkInfoPopover(analysed) {
    if (!bucLinkInteractionEngaged || bucLinkInfoMode === "off" || !analysed?.link || !analysed?.entry?.visualTarget) return;

    bucCloseLinkInfoPopover();

    const { link, entry } = analysed;
    const state = typeof bucLinkHighlightState === "function"
        ? bucLinkHighlightState(link)
        : { key: "unknown", icon: "?", label: "Unknown" };

    const card = document.createElement("aside");
    card.id = "beforeuclick-link-info";
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-label", "BeforeUClick link information");
    bucApplyInjectedUiPreferences(card);

    const stateColour = state.key === "high" ? "#b42318"
        : state.key === "caution" ? "#8a5300"
            : state.key === "review" ? "#725a00"
                : state.key === "no-concerns" ? "#174ea6"
                    : "#4b5563";
    const stateBackground = state.key === "high" ? "#fce8e6"
        : state.key === "caution" ? "#fef7e0"
            : state.key === "review" ? "#fff8d8"
                : state.key === "no-concerns" ? "#e8f0fe"
                    : "#f3f4f6";
    const border = bucCurrentUiPreferences.highContrast ? "2px solid #111827" : "1px solid #cfd4dc";
    Object.assign(card.style, {
        position: "fixed",
        zIndex: "2147483647",
        width: `${bucUiPx(350)}px`,
        maxWidth: "calc(100vw - 20px)",
        maxHeight: "55vh",
        overflowY: "auto",
        padding: bucCurrentUiPreferences.density === "compact" ? "10px" : "13px",
        background: "#ffffff",
        color: "#202124",
        border,
        borderRadius: "10px",
        boxShadow: "0 10px 28px rgba(32,33,36,.28)",
        borderLeft: `5px solid ${stateColour}`,
        fontFamily: "Arial, Helvetica, sans-serif",
        fontSize: `${bucUiPx(13)}px`,
        lineHeight: "1.42"
    });

    const status = document.createElement("div");
    const statusMessage = typeof bucLinkBadgeMessage === "function"
        ? bucLinkBadgeMessage(state)
        : { text: `${state.icon || "?"} ${state.label}` };
    status.textContent = statusMessage.text;
    Object.assign(status.style, {
        display: "inline-flex",
        alignItems: "center",
        padding: "4px 8px",
        borderRadius: "999px",
        border: `1px solid ${stateColour}`,
        background: stateBackground,
        fontWeight: "700",
        color: stateColour,
        fontSize: `${bucUiPx(13)}px`
    });

    const destination = document.createElement("div");
    destination.textContent = `Actual destination: ${link.url || "Destination unavailable"}`;
    Object.assign(destination.style, {
        marginTop: "8px",
        padding: "7px 8px",
        background: "#f8f9fa",
        borderRadius: "6px",
        overflowWrap: "anywhere",
        fontFamily: "Consolas, 'Courier New', monospace",
        fontSize: `${bucUiPx(11)}px`
    });

    const displayLine = document.createElement("div");
    displayLine.textContent = `Displayed: ${link.text || link.altText || "(no visible text)"}`;
    Object.assign(displayLine.style, { marginTop: "7px", color: "#3c4043", fontSize: `${bucUiPx(11)}px`, overflowWrap: "anywhere" });

    card.append(status, displayLine, destination);

    if (link.originalUrl && link.originalUrl !== link.url) {
        const wrapperLine = document.createElement("div");
        wrapperLine.textContent = `Wrapper link: ${link.originalUrl}`;
        Object.assign(wrapperLine.style, {
            marginTop: "5px", padding: "6px 7px", background: "#f8f9fa", borderRadius: "6px",
            color: "#5f6368", overflowWrap: "anywhere", fontFamily: "Consolas, 'Courier New', monospace",
            fontSize: `${bucUiPx(10)}px`
        });
        card.appendChild(wrapperLine);
    }

    const registeredDomain = link.domain?.registrableDomain || link.domain?.hostname || "";
    if (registeredDomain) {
        const domainLine = document.createElement("div");
        domainLine.textContent = `Registered domain: ${registeredDomain}`;
        Object.assign(domainLine.style, { marginTop: "6px", color: "#5f6368", fontSize: `${bucUiPx(11)}px` });
        card.appendChild(domainLine);
    }

    const reasonsTitle = document.createElement("div");
    reasonsTitle.textContent = "Why";
    Object.assign(reasonsTitle.style, { marginTop: "10px", fontWeight: "700" });

    const reasons = document.createElement("ul");
    Object.assign(reasons.style, { margin: "5px 0 0", paddingLeft: "18px" });

    const warningTexts = (link.warnings || []).slice(0, 3);
    if (warningTexts.length) {
        warningTexts.forEach(text => {
            const item = document.createElement("li");
            item.textContent = text;
            item.style.marginBottom = "4px";
            reasons.appendChild(item);
        });
    } else {
        const item = document.createElement("li");
        item.textContent = link.reference?.officialOrganisation
            ? `Destination matches a sourced first-party reference for ${link.reference.officialOrganisation.name}.`
            : "No specific concerning link evidence was found; this remains a checked result, not a safety guarantee.";
        reasons.appendChild(item);
    }

    const actions = document.createElement("div");
    Object.assign(actions.style, {
        display: "flex",
        gap: "7px",
        flexWrap: "wrap",
        marginTop: "11px"
    });

    function smallButton(text) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = text;
        Object.assign(button.style, {
            border: "1px solid #dadce0",
            borderRadius: "7px",
            background: "#ffffff",
            color: "#174ea6",
            padding: "6px 9px",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: `${bucUiPx(11)}px`
        });
        return button;
    }

    const show = smallButton("Show in email");
    show.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        if (link.id && typeof bucRevealLink === "function") bucRevealLink(link.id);
    });

    const report = smallButton("Inspect this link");
    report.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        bucOpenFullReportFromContent(link.id || "");
    });

    actions.append(show, report);
    card.append(reasonsTitle, reasons, actions);
    document.body.appendChild(card);
    bucPositionLinkInfoPopover(card, entry.visualTarget);

    card.addEventListener("pointerenter", () => clearTimeout(bucLinkPopoverCloseTimer));
    card.addEventListener("pointerleave", () => bucScheduleLinkInfoClose());
}

/** Installs hover/focus listeners once. Only already-analysed email anchors can produce a card. */
function bucInstallLinkInfoPopover() {
    if (bucLinkPopoverInstalled) return;
    bucLinkPopoverInstalled = true;

    document.addEventListener("pointerover", event => {
        if (!bucLinkInteractionEngaged || bucLinkInfoMode === "off") return;
        const target = event.target instanceof Element ? event.target : null;
        const badge = target?.closest(".beforeuclick-link-status-badge");
        if (badge?.dataset.linkId) {
            const linkId = badge.dataset.linkId;
            const link = typeof bucCurrentAnalysedLinks !== "undefined" ? bucCurrentAnalysedLinks.get(linkId) : null;
            const entry = typeof bucGetLinkRegistryEntry === "function" ? bucGetLinkRegistryEntry(linkId) : null;
            if (link && entry) {
                clearTimeout(bucLinkPopoverCloseTimer);
                bucShowLinkInfoPopover({ linkId, link, entry });
            }
            return;
        }

        const anchor = target?.closest("a[href]");
        if (!anchor || anchor.closest("#beforeuclick-link-info")) return;
        const analysed = typeof bucFindAnalysedLinkForAnchor === "function"
            ? bucFindAnalysedLinkForAnchor(anchor)
            : null;
        if (!analysed) return;
        clearTimeout(bucLinkPopoverCloseTimer);
        bucShowLinkInfoPopover(analysed);
    }, true);

    document.addEventListener("pointerout", event => {
        const target = event.target instanceof Element ? event.target : null;
        if (target?.closest("a[href], .beforeuclick-link-status-badge")) bucScheduleLinkInfoClose();
    }, true);

    document.addEventListener("focusin", event => {
        if (!bucLinkInteractionEngaged || bucLinkInfoMode === "off") return;
        const target = event.target instanceof Element ? event.target : null;

        const badge = target?.closest(".beforeuclick-link-status-badge");
        if (badge?.dataset.linkId) {
            const linkId = badge.dataset.linkId;
            const link = typeof bucCurrentAnalysedLinks !== "undefined"
                ? bucCurrentAnalysedLinks.get(linkId)
                : null;
            const entry = typeof bucGetLinkRegistryEntry === "function"
                ? bucGetLinkRegistryEntry(linkId)
                : null;
            if (link && entry) bucShowLinkInfoPopover({ linkId, link, entry });
            return;
        }

        const anchor = target?.closest("a[href]");
        if (!anchor) return;
        const analysed = typeof bucFindAnalysedLinkForAnchor === "function"
            ? bucFindAnalysedLinkForAnchor(anchor)
            : null;
        if (analysed) bucShowLinkInfoPopover(analysed);
    }, true);

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") bucCloseLinkInfoPopover();
    }, true);

    // A contextual card should never remain detached from its link while the page moves.
    window.addEventListener("scroll", bucCloseLinkInfoPopover, true);
    window.addEventListener("resize", bucCloseLinkInfoPopover, { passive: true });
}
