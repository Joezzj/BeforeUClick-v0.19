// tests/v014_static_smoke_test.js
// Lightweight source-level assertions that do not require a browser DOM.
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

function mustContain(file, values) {
    const text = fs.readFileSync(path.join(root, file), "utf8");
    values.forEach(value => {
        if (!text.includes(value)) throw new Error(`${file} missing: ${value}`);
    });
}

mustContain("manifest.json", [
    "https://mail.google.com/*",
    "https://outlook.live.com/*",
    "https://mail.yahoo.com/*",
    "adapters/provider_router.js",
    "ui/link_popover.js"
]);

mustContain("settings/preferences.js", [
    'fontSize: "normal"',
    'linkInfoMode: "hover-focus"',
    'highContrast: false',
    'reducedMotion: false'
]);

mustContain("adapters/provider_router.js", [
    'key: "gmail"',
    'key: "outlook"',
    'key: "yahoo"'
]);

mustContain("report/report.html", [
    "Sender and message details",
    "Why this result?",
    "Wording matches"
]);

console.log("v0.14 static smoke test: PASS");
