// background/service_worker.js
// Stores only daily aggregate check counters and updates the toolbar badge.
// No email content, sender, URL or analysis report is stored.

const BUC_STATS_KEY = "beforeUClickDailyStats";
const BUC_BADGE_COLOR = "#A5690F";

/** Returns a local-calendar date key rather than a UTC date. */
function bucTodayKey() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

/** Loads today's counters, resetting stale counters automatically. */
async function bucGetDailyStats() {
    const data = await chrome.storage.local.get([BUC_STATS_KEY]);
    const stored = data[BUC_STATS_KEY];

    if (!stored || stored.date !== bucTodayKey()) {
        const fresh = { date: bucTodayKey(), scanned: 0, concern: 0, high: 0 };
        await chrome.storage.local.set({ [BUC_STATS_KEY]: fresh });
        return fresh;
    }

    return {
        date: stored.date,
        scanned: Number(stored.scanned) || 0,
        concern: Number(stored.concern) || 0,
        high: Number(stored.high) || 0
    };
}

/** Reflects today's concern count in the toolbar badge without exposing message data. */
async function bucUpdateToolbarBadge(stats) {
    const count = Number(stats?.concern) || 0;
    await chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
    if (count > 0) {
        await chrome.action.setBadgeBackgroundColor({ color: BUC_BADGE_COLOR });
    }
}

/** Records one manual BeforeUClick check using only the final verdict key. */
async function bucRecordScan(verdictKey) {
    const stats = await bucGetDailyStats();
    stats.scanned += 1;

    if (["review", "caution", "high"].includes(verdictKey)) {
        stats.concern += 1;
    }
    if (verdictKey === "high") {
        stats.high += 1;
    }

    await chrome.storage.local.set({ [BUC_STATS_KEY]: stats });
    await bucUpdateToolbarBadge(stats);
    return stats;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "BUC_RECORD_SCAN") {
        bucRecordScan(message.verdictKey)
            .then(stats => sendResponse({ ok: true, stats }))
            .catch(error => sendResponse({ ok: false, error: String(error) }));
        return true;
    }



    if (message?.type === "BUC_OPEN_FULL_REPORT_FROM_POPUP") {
        const sourceTab = Number(message.sourceTab);
        if (!Number.isInteger(sourceTab)) {
            sendResponse({ ok: false, error: "Source webmail tab unavailable." });
            return false;
        }
        const focus = message.focusLinkId ? `&focusLink=${encodeURIComponent(message.focusLinkId)}` : "";
        const url = chrome.runtime.getURL(`report/report.html?sourceTab=${sourceTab}${focus}`);
        chrome.tabs.create({ url })
            .then(tab => sendResponse({ ok: true, tabId: tab.id }))
            .catch(error => sendResponse({ ok: false, error: String(error) }));
        return true;
    }

    if (message?.type === "BUC_OPEN_FULL_REPORT") {
        const sourceTab = _sender?.tab?.id;
        if (!Number.isInteger(sourceTab)) {
            sendResponse({ ok: false, error: "Source webmail tab unavailable." });
            return false;
        }

        const focus = message.focusLinkId ? `&focusLink=${encodeURIComponent(message.focusLinkId)}` : "";
        const url = chrome.runtime.getURL(`report/report.html?sourceTab=${sourceTab}${focus}`);
        chrome.tabs.create({ url })
            .then(tab => sendResponse({ ok: true, tabId: tab.id }))
            .catch(error => sendResponse({ ok: false, error: String(error) }));
        return true;
    }

    if (message?.type === "BUC_GET_STATS") {
        bucGetDailyStats()
            .then(stats => sendResponse({ ok: true, stats }))
            .catch(error => sendResponse({ ok: false, error: String(error) }));
        return true;
    }

    return false;
});

chrome.runtime.onInstalled.addListener(() => {
    bucGetDailyStats().then(bucUpdateToolbarBadge);
});
chrome.runtime.onStartup.addListener(() => {
    bucGetDailyStats().then(bucUpdateToolbarBadge);
});
