const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const s = file => fs.readFileSync(path.join(root, file), "utf8");

const manifest = JSON.parse(s("manifest.json"));
if (!["0.15.6", "0.15.7", "0.16.0", "0.18.0", "0.18.1", "0.18.2"].includes(manifest.version)) throw new Error("Unexpected Yahoo-compatible v0.15 build.");
if (!manifest.content_scripts[0].matches.includes("https://mail.yahoo.com/*")) {
    throw new Error("Yahoo host match missing.");
}

const yahoo = s("adapters/yahoo/extraction.js");
[
    "bucYahooBodyCandidates",
    "bucYahooLooksLikeCompose",
    "bucYahooBodyCandidateScore",
    "candidateCount",
    "[data-test-id*='message' i][data-test-id*='body' i]",
    "[aria-label*='from:' i][aria-label*='@']",
    "[data-test-id='message-bcc']",
    "bucYahooTextRootThenDocument"
].forEach(value => {
    if (!yahoo.includes(value)) throw new Error(`Yahoo hardening missing: ${value}`);
});

console.log("v0.15.6 Yahoo hardening static test: PASS");
