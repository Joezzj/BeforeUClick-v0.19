// adapters/outlook/headers.js
// Outlook Web header acquisition for BeforeUClick v0.18.
// Best-effort opens View message details only when the expected English controls are uniquely found.

function bucOutlookFindRawHeaderText() {
    const nodes = Array.from(document.querySelectorAll([
        "[role='dialog'] pre",
        "[role='dialog'] textarea",
        "[role='dialog'] [role='textbox']",
        "[role='dialog'] [contenteditable='false']",
        "pre",
        "textarea"
    ].join(", ")));
    return bucFindRawHeaderTextInNodes(nodes);
}

function bucOutlookFindTextAction(text) {
    const wanted = String(text || "").trim().toLowerCase();
    const elements = Array.from(document.querySelectorAll("button, [role='button'], [role='menuitem'], [role='option']"))
        .filter(element => bucAdapterIsVisible(element))
        .filter(element => String(element.innerText || element.textContent || element.getAttribute("aria-label") || "").trim().toLowerCase().includes(wanted));
    return elements.length === 1 ? elements[0] : null;
}

function bucOutlookMoreActionsButton(context) {
    const scopes = [context?.root, document].filter(Boolean);
    for (const scope of scopes) {
        const candidates = Array.from(scope.querySelectorAll?.([
            "button[aria-label*='More actions' i]",
            "button[title*='More actions' i]",
            "[role='button'][aria-label*='More actions' i]",
            "button[aria-label='More' i]"
        ].join(", ")) || []).filter(bucAdapterIsVisible);
        if (candidates.length === 1) return candidates[0];
    }
    return null;
}

function bucOutlookWait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function bucOutlookTryOpenMessageDetails(context) {
    const existing = bucOutlookFindRawHeaderText();
    if (existing) return { rawHeaders: existing, openedByPrototype: false };

    const more = bucOutlookMoreActionsButton(context);
    if (!more) return { rawHeaders: "", openedByPrototype: false };

    more.click();
    await bucOutlookWait(120);

    const details = bucOutlookFindTextAction("View message details");
    if (!details) {
        // Do not leave Outlook's More-actions menu hanging open when the expected action is absent
        // (for example after a provider DOM/text change or a non-English interface).
        try { more.click(); } catch (_error) { /* Best-effort UI cleanup only. */ }
        return { rawHeaders: "", openedByPrototype: false };
    }

    details.click();
    for (let attempt = 0; attempt < 8; attempt += 1) {
        await bucOutlookWait(100);
        const rawHeaders = bucOutlookFindRawHeaderText();
        if (rawHeaders) return { rawHeaders, openedByPrototype: true };
    }

    return { rawHeaders: "", openedByPrototype: true };
}

function bucOutlookCloseMessageDetailsIfOpened(openedByPrototype) {
    if (!openedByPrototype) return;
    const dialogs = Array.from(document.querySelectorAll("[role='dialog']")).filter(bucAdapterIsVisible);
    for (const dialog of dialogs) {
        const text = String(dialog.innerText || dialog.textContent || "");
        const looksLikeDetails = bucLooksLikeRawHeaderText(text) || /message details|internet headers/i.test(text);
        if (!looksLikeDetails) continue;
        const close = dialog.querySelector("button[aria-label='Close' i], button[title='Close' i], [role='button'][aria-label='Close' i]");
        if (close) close.click();
        return;
    }
}

async function acquireOutlookHeaders(context, metadata = {}) {
    let captured = { rawHeaders: "", openedByPrototype: false };
    try {
        captured = await bucOutlookTryOpenMessageDetails(context);
        if (captured.rawHeaders) {
            return {
                provider: "outlook",
                status: "full",
                source: "outlook-view-message-details",
                rawHeaders: captured.rawHeaders,
                limitations: []
            };
        }
    } catch (_error) {
        // Fall through to visible summary instead of failing the whole email check.
    } finally {
        // If BeforeUClick opened the details UI, do not leave it covering the user's mailbox even
        // when header recognition fails or Outlook changes the dialog contents.
        bucOutlookCloseMessageDetailsIfOpened(captured.openedByPrototype);
    }

    const hasSummary = Boolean(metadata.replyTo || metadata.mailedBy || metadata.signedBy);
    return {
        provider: "outlook",
        status: hasSummary ? "partial" : "unavailable",
        source: hasSummary ? "outlook-visible-summary" : "outlook-visible-message",
        rawHeaders: "",
        limitations: ["Outlook View message details headers could not be captured automatically; visible message data was retained."]
    };
}
