# BeforeUClick Reference Dataset v1.0

This folder is the first reasonably stable reference-data snapshot intended to feed the BeforeUClick checker.

It is kept separate from the executable extension until the v0.13 calibration pass.

## Core rule

Reference data and score policy are kept separate from checking logic:

- `organisation_references.js` — organisations, aliases, official domains, email domains and domain roles.
- `controlled_namespaces.js` — moderated/restricted namespaces.
- `wording_patterns.js` — sourced wording/behaviour categories and implementation regex examples.
- `threat_sources.js` — external known-bad/threat-intelligence source definitions.
- `reputation_sources.js` — optional/future positive reputation sources.
- `evidence_classes.js` — central evidence classes and suggested score effects.
- `README_REFERENCES.md` — full `[n]` source details.
- `DATASET_SUMMARY.md` — counts, scope and integration notes.

## Important scoring rules

1. The normal uncertainty baseline remains **15**.
2. No match / unavailable data = **0 score change**.
3. A score below 15 requires explicit reassuring evidence.
4. Official-domain evidence is not a guarantee of safety.
5. Multi-tenant/user-content platforms do **not** receive normal reassuring deductions merely because the provider is legitimate.
6. Strong and critical evidence cannot be cancelled by reassuring evidence.
7. Wording is supporting evidence and remains capped by the scoring engine.
8. Known-threat feeds are treated as much stronger evidence than wording or ordinary URL heuristics.
9. Score values in `evidence_classes.js` are **suggested starting values for calibration**, not probabilities.

## Domain roles

- `first-party` — organisation-controlled destination; eligible for normal reassurance.
- `sender-domain` — legitimate email-sending domain; supports sender identity only.
- `short-link` — organisation-controlled short-link; small reassurance only and destination should still be resolved.
- `platform` — legitimate provider but can host user/customer-controlled content; identify the provider but normally give no reassurance deduction.
- `user-content` — explicitly user-hosted/shared content; no reassurance deduction.
- `infrastructure` — technical/CDN/API infrastructure; normally no user-facing trust deduction.

## Status

Reference Dataset v1.0 — prepared for the v0.13 integration/calibration pass.
Reviewed: 7 September 2026.
