const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const text = file => fs.readFileSync(path.join(root, file), "utf8");
const manifest = JSON.parse(text("manifest.json"));

if (!["0.18.0", "0.18.1", "0.18.2"].includes(manifest.version)) throw new Error("Manifest is not v0.18.0");
[
    "analysis/headers/parser.js",
    "analysis/headers/alignment.js",
    "analysis/headers/authentication.js",
    "analysis/headers/evidence.js",
    "adapters/gmail/headers.js",
    "adapters/outlook/headers.js",
    "adapters/yahoo/headers.js"
].forEach(file => {
    if (!manifest.content_scripts[0].js.includes(file)) throw new Error(`Manifest missing ${file}`);
});

const router = text("adapters/provider_router.js");
if (!router.includes("bucAcquireProviderHeaders")) throw new Error("Provider header router missing");

const content = text("content.js");
[
    "bucAcquireProviderHeaders",
    "bucBuildAuthenticationModel",
    "bucMergeMetadataFromAuthentication",
    "analyseAuthentication",
    "modules.authentication"
].forEach(value => {
    if (!content.includes(value)) throw new Error(`Pipeline integration missing ${value}`);
});

const report = text("report/report.html");
if (!report.includes("Authentication &amp; Internet headers")) throw new Error("Full report auth section missing");
if (!report.includes("Raw Internet headers")) throw new Error("Raw header inspection section missing");

console.log("v0.18 architecture smoke test: PASS");
