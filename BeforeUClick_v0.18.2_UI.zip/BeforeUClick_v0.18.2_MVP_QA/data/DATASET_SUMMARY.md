# Reference Dataset v1.0 — Summary

## Coverage

### Organisation references
36 organisation groups currently represented:

Global / account services:
- Microsoft
- Google
- Apple
- PayPal
- Amazon / AWS
- Meta / Facebook / Instagram
- LinkedIn
- Dropbox
- Adobe
- Netflix
- Docusign
- Xero

New Zealand government / public:
- Inland Revenue
- NZTA Waka Kotahi
- ACC
- New Zealand Police
- Work and Income
- RealMe

New Zealand consumer / marketplace:
- NZ Post
- Trade Me

New Zealand banks:
- ANZ
- ASB
- BNZ
- Westpac NZ
- Kiwibank

New Zealand telecommunications:
- Spark
- One New Zealand
- 2degrees

New Zealand utilities:
- Contact Energy
- Mercury
- Meridian Energy
- Genesis Energy

Travel / shipping:
- Air New Zealand
- DHL
- FedEx
- UPS

### Wording / behaviour categories
32 grouped categories, including:
- urgency
- account suspension
- account compromise
- credential verification
- password/PIN request
- MFA/OTP request
- personal information
- card/banking data
- payment/invoice pressure
- changed bank details
- refund/reward
- prize/giveaway
- gift cards
- secrecy
- remote access/software install
- parcel delivery
- toll/vehicle
- link pressure
- unexpected attachments
- generic greetings
- boss/favour requests
- mailbox quota
- investment/crypto
- seed phrase
- friend/family emergency
- job/recruitment
- subscription renewal
- document/e-sign
- QR/quishing
- fake support/callback
- police/legal authority
- charity/disaster

## Score-affecting evidence classes

Reassuring:
- OFFICIAL_SENDER_DOMAIN *
- OFFICIAL_DESTINATION *
- CONTROLLED_NAMESPACE *
- OFFICIAL_SHORT_LINK *
- KNOWN_LOCAL_SENDER *

Neutral/context only:
- PLATFORM_PROVIDER
- USER_CONTENT_HOST
- INFRASTRUCTURE_DOMAIN
- DNSSEC_PRESENT

Concerning:
- WORDING_WEAK *
- WORDING_MEDIUM *
- WORDING_STRONG *
- KNOWN_PHISHING *
- KNOWN_MALWARE *
- DOMAIN_BLOCKLIST_STRONG *

Future weak reassuring:
- ESTABLISHED_DOMAIN *
- LONG_REGISTRATION_HISTORY *
- HSTS_PRELOAD *

`*` = intended to affect the score after calibration/integration.

## Key safety improvement over older reference lists

The dataset no longer treats every legitimate provider domain as equally reassuring.

Example:
- `microsoft.com` can provide first-party reassurance.
- `sharepoint.com` is recognised as Microsoft infrastructure/platform but is score-neutral because tenants can host their own content.
- `dropbox.com` and `docusign.com` are recognised providers but are score-neutral for destination safety because legitimate platform accounts can be abused.
- `amazonaws.com` is recognised infrastructure/user-hosting, not a trusted destination.

This prevents the positive scoring system from becoming an easy bypass.

## Next integration step

For v0.13:
1. Update `analysis/references.js` to read `domainRules` and `scoreKeys`.
2. Update sender scoring to apply `OFFICIAL_SENDER_DOMAIN` only to sender-domain rules.
3. Update link scoring/reassurance to apply `OFFICIAL_DESTINATION` only to first-party rules.
4. Keep platform/user-content recognition visible in explanations but score-neutral.
5. Update wording scoring to map each group's `evidenceClass` through `BUC_REFERENCE_EVIDENCE_CLASSES`.
6. Build fixed legitimate/phishing test samples and calibrate the suggested weights.
