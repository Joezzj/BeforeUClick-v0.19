const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const s = file => fs.readFileSync(path.join(root, file), "utf8");

const manifest = JSON.parse(s("manifest.json"));
if (!["0.15.7", "0.16.0", "0.18.0", "0.18.1", "0.18.2"].includes(manifest.version)) throw new Error("Unexpected badge-responsive build.");

const highlighting = s("ui/highlighting.js");
[
    "bucLinkBadgeScrolling",
    "bucLinkBadgeScrollTimer",
    "function bucBeginLinkBadgeScroll",
    'badge.style.visibility = "hidden"',
    'badge.style.pointerEvents = "none"',
    "bucPositionAllLinkStatusBadges(false)",
    "55",
    'window.addEventListener("wheel", bucBeginLinkBadgeScroll',
    'window.addEventListener("touchmove", bucBeginLinkBadgeScroll',
    'window.addEventListener("scroll", bucBeginLinkBadgeScroll, true)'
].forEach(value => {
    if (!highlighting.includes(value)) throw new Error(`Missing responsive badge behaviour: ${value}`);
});

const popover = s("ui/link_popover.js");
if (!popover.includes('window.addEventListener("scroll", bucCloseLinkInfoPopover, true)')) {
    throw new Error("Popover does not close on scroll.");
}

console.log("v0.15.7 badge responsiveness smoke test: PASS");
