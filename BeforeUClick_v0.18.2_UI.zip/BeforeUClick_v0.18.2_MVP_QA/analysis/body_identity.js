// analysis/body_identity.js
// Limited identity checks for email addresses written inside the current message body.

/** Extracts unique email addresses written as text in the current message body. */
function bucExtractBodyEmailAddresses(text) {
    const matches = String(text || "").match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
    return [...new Set(matches.map(item => item.toLowerCase()))];
}

/** Creates one body-identity evidence item for scoring/reporting. */
function bucBodyIdentityEvidence(code, points, text, strength = "weak", details = {}) {
    return {
        code,
        category: "identity",
        source: "body-identity",
        points,
        score: points,
        strength,
        text,
        ...details
    };
}

/**
 * Checks contact email addresses written inside the current message body.
 * Evidence is intentionally capped because legitimate messages can mention third-party contacts.
 */
function analyseBodyIdentity(text) {
    const bodyText = String(text || "");
    const addresses = bucExtractBodyEmailAddresses(bodyText);
    const claimedOrganisations = bucFindClaimedOrganisations(bodyText);
    const evidence = [];

    for (const address of addresses) {
        const domain = bucEmailDomain(address);
        if (!domain) continue;

        const typosquat = bucFindTyposquatReference(domain);
        if (typosquat) {
            evidence.push(bucBodyIdentityEvidence(
                "body-email-typosquat",
                12,
                `A contact address written in the email (${address}) uses a domain very close to recognised ${typosquat.organisation.name} domain ${typosquat.officialDomain}.`,
                "medium",
                { emailAddress: address, domain }
            ));
            if (evidence.length >= 3) break;
            continue;
        }

        for (const reference of claimedOrganisations) {
            const official = bucReferenceDestinationDomains(reference)
                .some(item => bucHostnameMatchesDomain(domain, item));

            if (!official) {
                evidence.push(bucBodyIdentityEvidence(
                    "body-contact-brand-mismatch",
                    5,
                    `The message references ${reference.name} and contains contact address ${address}, whose domain is not in the local ${reference.name} reference.`,
                    "weak",
                    { emailAddress: address, domain, organisation: reference.name }
                ));
                break;
            }
        }

        if (evidence.length >= 3) break;
    }

    return {
        score: Math.min(evidence.reduce((total, item) => total + item.points, 0), 15),
        warnings: evidence.map(item => item.text),
        evidence,
        addresses
    };
}
