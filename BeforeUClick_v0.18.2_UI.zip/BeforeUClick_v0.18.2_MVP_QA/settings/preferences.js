// settings/preferences.js
// Shared local-only preferences. No email body, URL history or analysis report is stored here.

const BUC_PREFERENCE_KEY = "beforeUClickPreferences";

const BUC_DEFAULT_PREFERENCES = Object.freeze({
    highlightMode: "concerns",
    clickGuardMode: "strong-only",
    linkInfoMode: "hover-focus",
    fontSize: "normal",
    density: "comfortable",
    highContrast: false,
    reducedMotion: false,
    inboxPreviewMode: "off",
    knownSenders: []
});

function bucNormaliseKnownSender(value) {
    return String(value || "").trim().toLowerCase();
}

/** Returns a validated preference object merged with current defaults. */
function bucNormalisePreferences(value) {
    const source = value && typeof value === "object" ? value : {};
    const allowedHighlightModes = new Set(["concerns", "all", "off"]);
    const allowedClickGuardModes = new Set(["strong-only", "high-only", "caution-high", "off"]);
    const allowedLinkInfoModes = new Set(["hover-focus", "off"]);
    const allowedFontSizes = new Set(["normal", "large", "xlarge"]);
    const allowedDensity = new Set(["comfortable", "compact"]);
    const allowedInboxPreviewModes = new Set(["off", "concerns"]);

    return {
        highlightMode: allowedHighlightModes.has(source.highlightMode) ? source.highlightMode : BUC_DEFAULT_PREFERENCES.highlightMode,
        clickGuardMode: allowedClickGuardModes.has(source.clickGuardMode) ? source.clickGuardMode : BUC_DEFAULT_PREFERENCES.clickGuardMode,
        linkInfoMode: allowedLinkInfoModes.has(source.linkInfoMode) ? source.linkInfoMode : BUC_DEFAULT_PREFERENCES.linkInfoMode,
        fontSize: allowedFontSizes.has(source.fontSize) ? source.fontSize : BUC_DEFAULT_PREFERENCES.fontSize,
        density: allowedDensity.has(source.density) ? source.density : BUC_DEFAULT_PREFERENCES.density,
        highContrast: source.highContrast === true,
        reducedMotion: source.reducedMotion === true,
        inboxPreviewMode: allowedInboxPreviewModes.has(source.inboxPreviewMode) ? source.inboxPreviewMode : BUC_DEFAULT_PREFERENCES.inboxPreviewMode,
        knownSenders: [...new Set(
            (Array.isArray(source.knownSenders) ? source.knownSenders : [])
                .map(bucNormaliseKnownSender)
                .filter(Boolean)
        )]
    };
}

async function bucGetPreferences() {
    const data = await chrome.storage.local.get([BUC_PREFERENCE_KEY]);
    return bucNormalisePreferences(data[BUC_PREFERENCE_KEY]);
}

async function bucSavePreferences(preferences) {
    const normalised = bucNormalisePreferences(preferences);
    await chrome.storage.local.set({ [BUC_PREFERENCE_KEY]: normalised });
    return normalised;
}

async function bucAddKnownSender(email) {
    const address = bucNormaliseKnownSender(email);
    if (!address) return bucGetPreferences();
    const current = await bucGetPreferences();
    if (!current.knownSenders.includes(address)) current.knownSenders.push(address);
    return bucSavePreferences(current);
}

async function bucRemoveKnownSender(email) {
    const address = bucNormaliseKnownSender(email);
    const current = await bucGetPreferences();
    current.knownSenders = current.knownSenders.filter(item => item !== address);
    return bucSavePreferences(current);
}

function bucIsKnownSender(email, preferences) {
    const address = bucNormaliseKnownSender(email);
    return Boolean(address && preferences?.knownSenders?.includes(address));
}

/** Applies extension-page-only accessibility preferences without touching the host webmail page. */
function bucApplyExtensionPagePreferences(preferences) {
    if (!document?.body) return;
    const prefs = bucNormalisePreferences(preferences);
    document.body.dataset.fontSize = prefs.fontSize;
    document.body.dataset.density = prefs.density;
    document.body.dataset.highContrast = prefs.highContrast ? "true" : "false";
    document.body.dataset.reducedMotion = prefs.reducedMotion ? "true" : "false";
}
