const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const s = file => fs.readFileSync(path.join(root, file), "utf8");

const content = s("content.js");
[
    "recordScan = true",
    'message.type === "REANALYSE_CURRENT_EMAIL"',
    "recordScan: false",
    "bucDisengageIfMessageChanged"
].forEach(v => { if (!content.includes(v)) throw new Error(`content missing ${v}`); });

const full = s("report/report.js");
[
    "let bucFullSourceTabId = null",
    'type: "REANALYSE_CURRENT_EMAIL"',
    "bucFullRender(refreshed)"
].forEach(v => { if (!full.includes(v)) throw new Error(`full report missing ${v}`); });

const floating = s("ui/report.js");
if (floating.includes('{ once: true }')) throw new Error("One-shot resize handler remains.");
if (!floating.includes('window.removeEventListener("resize", resizeHandler)')) {
    throw new Error("Resize-listener cleanup missing.");
}

const manifest = JSON.parse(s("manifest.json"));
if (!["0.15.4", "0.15.5", "0.15.6", "0.15.7", "0.16.0", "0.18.0", "0.18.1", "0.18.2"].includes(manifest.version)) throw new Error("Unexpected v0.15 final manifest build.");

console.log("v0.15 Final QA smoke test: PASS");
