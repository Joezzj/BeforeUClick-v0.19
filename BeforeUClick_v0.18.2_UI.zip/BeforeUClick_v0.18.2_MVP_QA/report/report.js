// report/report.js
// Read-only full report page. It requests the in-memory last report from the source webmail tab.

const loadingEl = document.getElementById("loading");
const errorEl = document.getElementById("error");
const reportEl = document.getElementById("report");
let bucFullSourceTabId = null;

function bucFullText(tag, text, className = "") {
    const el = document.createElement(tag);
    if (className) el.className = className;
    el.textContent = text == null ? "" : String(text);
    return el;
}

function bucFullSigned(value) {
    const n = Number(value) || 0;
    return n > 0 ? `+${n}` : String(n);
}

function bucFullRow(container, label, value) {
    const row = bucFullText("div", "", "row");
    row.append(bucFullText("strong", label), bucFullText("span", value || "Not available"));
    container.appendChild(row);
}

function bucFullError(message) {
    loadingEl.classList.add("hidden");
    errorEl.textContent = message;
    errorEl.classList.remove("hidden");
}

function bucFullMessageTab(tabId, message) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, response => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve(response);
        });
    });
}

function bucFullApplyPreferences(prefs) {
    document.body.dataset.fontSize = prefs.fontSize || "normal";
    document.body.dataset.highContrast = prefs.highContrast ? "true" : "false";
    if (prefs.reducedMotion) document.body.dataset.reducedMotion = "true";
}

function bucFullAuthenticationResultText(item) {
    const result = String(item?.result || "unavailable").toUpperCase();
    const trusted = item?.providerTrusted ? " · provider result" : "";
    return `${result}${trusted}`;
}

function bucFullRenderAuthentication(report) {
    const container = document.getElementById("authentication");
    const raw = document.getElementById("rawHeaders");
    const status = document.getElementById("authStatus");
    const auth = report.authentication || {};
    const acquisition = report.headerAcquisition || {};
    const alignment = auth.alignment || {};

    container.textContent = "";
    status.textContent = String(acquisition.status || auth.acquisitionStatus || "unavailable");

    bucFullRow(container, "Header source", acquisition.source || auth.source || "Not available");
    bucFullRow(container, "Header capture", acquisition.status || auth.acquisitionStatus || "unavailable");
    bucFullRow(container, "Visible / header From", auth.fromAddress || auth.headerFrom || "Not available");
    bucFullRow(container, "Reply-To", auth.replyTo || "Not present / not exposed");
    bucFullRow(container, "Return-Path", auth.returnPath || "Not present / not exposed");
    bucFullRow(container, "Message-ID", auth.messageId || "Not present / not exposed");

    const spfDomain = auth.spf?.domain ? ` · ${auth.spf.domain}` : "";
    bucFullRow(container, "SPF", `${bucFullAuthenticationResultText(auth.spf)}${spfDomain}`);

    const dkim = auth.dkim || [];
    if (dkim.length) {
        dkim.forEach((item, index) => {
            const details = [
                bucFullAuthenticationResultText(item),
                item.signingDomain ? `d=${item.signingDomain}` : "",
                item.selector ? `s=${item.selector}` : ""
            ].filter(Boolean).join(" · ");
            bucFullRow(container, `DKIM${dkim.length > 1 ? ` ${index + 1}` : ""}`, details);
        });
    } else {
        bucFullRow(container, "DKIM", "Not present / not exposed");
    }

    const dmarcDomain = auth.dmarc?.domain ? ` · ${auth.dmarc.domain}` : "";
    bucFullRow(container, "DMARC", `${bucFullAuthenticationResultText(auth.dmarc)}${dmarcDomain}`);
    bucFullRow(container, "ARC", bucFullAuthenticationResultText(auth.arc));

    bucFullRow(container, "From domain", alignment.fromDomain || "Not available");
    bucFullRow(container, "SPF alignment", alignment.spfDomain ? (alignment.spfAligned ? "Aligned" : "Not aligned") : "Not available");
    bucFullRow(container, "DKIM alignment", alignment.dkimDomains?.length ? (alignment.dkimAligned ? "Aligned" : "Not aligned") : "Not available");
    bucFullRow(container, "Reply-To alignment", alignment.replyToDomain ? (alignment.replyToAligned ? "Aligned" : "Different domain/organisation") : "Not available");
    bucFullRow(container, "Return-Path alignment", alignment.returnPathDomain ? (alignment.returnPathAligned ? "Aligned" : "Different domain/organisation") : "Not available");
    bucFullRow(container, "Received hops", Array.isArray(auth.received) && auth.received.length ? String(auth.received.length) : "Not available");

    if (Array.isArray(auth.limitations) && auth.limitations.length) {
        const limitationBox = bucFullText("div", "", "evidence-row");
        limitationBox.appendChild(bucFullText("strong", "Acquisition note"));
        const ul = document.createElement("ul");
        auth.limitations.forEach(item => ul.appendChild(bucFullText("li", item)));
        limitationBox.appendChild(ul);
        container.appendChild(limitationBox);
    }

    raw.textContent = auth.rawHeaders || "Full raw Internet headers were not captured for this check. Provider-visible summary information may still be shown above.";
}

function bucFullRenderEvidence(report) {
    const container = document.getElementById("evidence");
    const evidence = report.scoring?.evidence || [];
    document.getElementById("evidenceCount").textContent = evidence.length;
    container.textContent = "";

    if (!evidence.length) {
        container.appendChild(bucFullText("p", "No score-changing evidence rows were recorded.", "muted"));
        return;
    }

    evidence.forEach(item => {
        const row = bucFullText("div", "", "evidence-row");
        const title = bucFullText("div", "");
        title.append(
            bucFullText("span", String(item.strength || (Number(item.points) < 0 ? "reassuring" : "context")).toUpperCase(), "points"),
            bucFullText("strong", item.text || item.code || "Evidence")
        );
        row.appendChild(title);

        if (item.linkUrl) row.appendChild(bucFullText("div", item.linkUrl, "url"));
        if (item.references?.length) {
            row.appendChild(bucFullText("div", `References: ${item.references.map(v => `[${v}]`).join(", ")}`, "muted"));
        }
        if (item.notAppliedReason) row.appendChild(bucFullText("div", item.notAppliedReason, "muted"));
        container.appendChild(row);
    });
}

function bucFullLinkState(link) {
    const assessed = link?.assessment?.assessment;
    if (assessed?.key) {
        const labels = {
            "no-concerns": "No obvious concerns",
            unknown: "Unknown",
            review: "Review",
            caution: "Caution",
            high: "High concern"
        };
        return { key: assessed.key, icon: assessed.icon || "?", label: labels[assessed.key] || assessed.label || "Unknown" };
    }
    const warnings = link?.warningDetails || [];
    const strongest = warnings.reduce((best, item) => {
        const ranks = { weak: 1, medium: 2, strong: 3, critical: 4 };
        return (ranks[item.strength] || 0) > (ranks[best] || 0) ? item.strength : best;
    }, "");
    if (strongest === "critical") return { key: "high", icon: "!", label: "High concern" };
    if (strongest === "strong") return { key: "caution", icon: "⚠", label: "Caution" };
    if (strongest === "medium") return { key: "review", icon: "△", label: "Review" };
    return { key: "unknown", icon: "?", label: "Unknown" };
}

function bucFullRenderLinks(report) {
    const container = document.getElementById("links");
    const links = report.links || [];
    document.getElementById("linkCount").textContent = links.length;
    container.textContent = "";

    if (!links.length) {
        container.appendChild(bucFullText("p", "No HTTP/HTTPS links were found.", "muted"));
        return;
    }

    links.forEach((link, index) => {
        const details = bucFullText("details", "", "link-card");
        details.id = `report-link-${link.id || index}`;
        details.dataset.linkId = link.id || "";
        const state = bucFullLinkState(link);
        details.dataset.state = state.key;

        const summary = bucFullText(
            "summary",
            `${state.icon} Link ${index + 1} — ${state.label}`
        );
        const inside = bucFullText("div", "", "inside");

        bucFullRow(inside, "Type", link.type || "link");
        bucFullRow(inside, "Displayed", link.text || link.altText || "(no visible text)");
        const url = bucFullText("div", `Actual destination: ${link.url || "Destination unavailable"}`, "url");
        inside.appendChild(url);
        if (link.originalUrl && link.originalUrl !== link.url) {
            inside.appendChild(bucFullText("div", `Wrapper link: ${link.originalUrl}`, "url"));
        }

        if (link.domain?.registrableDomain) bucFullRow(inside, "Registered domain", link.domain.registrableDomain);
        if (link.domain?.publicSuffix) bucFullRow(inside, "Public suffix", link.domain.publicSuffix);

        if (link.reference?.officialOrganisation) {
            bucFullRow(inside, "Reference", `First-party: ${link.reference.officialOrganisation.name}`);
        } else if (link.reference?.recognisedOrganisation) {
            bucFullRow(inside, "Reference", `Recognised provider: ${link.reference.recognisedOrganisation.name} (${(link.reference.roles || []).join(", ") || "context"})`);
        }

        if (link.warnings?.length) {
            const ul = document.createElement("ul");
            link.warnings.forEach(warning => ul.appendChild(bucFullText("li", warning)));
            inside.appendChild(ul);
        }

        details.append(summary, inside);
        container.appendChild(details);
    });
}

function bucFullRenderWording(report) {
    const container = document.getElementById("wording");
    const matches = report.wordingMatches || [];
    document.getElementById("wordingCount").textContent = matches.length;
    container.textContent = "";

    if (!matches.length) {
        container.appendChild(bucFullText("p", "No configured wording pattern group matched.", "muted"));
        return;
    }

    matches.forEach(match => {
        const row = bucFullText("div", "", "evidence-row");
        row.appendChild(bucFullText("strong", `${match.label || match.id} — ${match.evidenceClass || "WORDING_WEAK"}`));
        if (match.matchedPhrases?.length) {
            row.appendChild(bucFullText("div", `Matched: ${match.matchedPhrases.join(", ")}`, "muted"));
        }
        container.appendChild(row);
    });
}


function bucFullRenderScoreBreakdown(report) {
    const container = document.getElementById("scoreBreakdown");
    container.textContent = "";
    const scores = report.scoring?.moduleScores || {};
    const caps = report.scoring?.caps || {};
    bucFullRow(container, "Internal evidence score", `${report.score ?? 15} / 100`);
    [
        ["Neutral / unknown baseline", scores.baseline, null],
        ["Identity / metadata / authentication", scores.identity, caps.identity],
        ["Links / destinations", scores.links, caps.links],
        ["Wording", scores.wording, caps.wording],
        ["Cross-signal combinations", scores.combinations, caps.combinations],
        ["Reassuring evidence adjustment", scores.reassurance, caps.reassurance]
    ].forEach(([label, value, cap]) => {
        bucFullRow(container, label, `${value ?? 0}${cap != null && label !== "Reassuring evidence adjustment" ? ` / ${cap}` : ""}`);
    });
    container.appendChild(bucFullText("p", "Developer/calibration information only. The numeric score is not a probability and is intentionally hidden from the normal user-facing result.", "muted"));
}

function bucFullRenderComponents(report) {
    const container = document.getElementById("components");
    const components = report.evaluation?.components || {};
    container.textContent = "";

    const order = ["sender", "authentication", "links", "wording"];
    const stateLabels = {
        "no-concerns": "No obvious concerns",
        unknown: "Unknown",
        review: "Review",
        caution: "Caution",
        high: "High concern"
    };

    order.forEach(key => {
        const component = components[key];
        if (!component?.assessment) return;
        const card = bucFullText("div", "", "component-card");
        card.dataset.state = component.assessment.key || "unknown";
        const head = bucFullText("div", "", "component-head");
        head.append(
            bucFullText("strong", component.label || key),
            bucFullText("span", `${component.assessment.icon || "?"} ${stateLabels[component.assessment.key] || component.assessment.label || "Unknown"}`, "component-state")
        );
        card.appendChild(head);
        card.appendChild(bucFullText("div", `Coverage: ${component.coverage?.label || "Partial"}`, "muted"));
        if (component.coverage?.note) card.appendChild(bucFullText("div", component.coverage.note, "muted"));

        const reason = (component.concerningEvidence || [])[0]?.text;
        if (reason) card.appendChild(bucFullText("div", reason, "component-reason"));
        else if (component.assessment.key === "no-concerns") card.appendChild(bucFullText("div", "No concern was identified within this completed component check.", "component-reason"));
        else if (component.assessment.key === "unknown") card.appendChild(bucFullText("div", "No strong concern was identified, but the available evidence is not enough to treat this component as known.", "component-reason"));

        container.appendChild(card);
    });
}

function bucFullRenderWarnings(report) {
    const container = document.getElementById("warnings");
    const warnings = report.warnings || [];
    document.getElementById("warningCount").textContent = warnings.length;
    container.textContent = "";
    if (!warnings.length) return container.appendChild(bucFullText("p", "No risk indicators were emitted by the current checks.", "muted"));
    const ul = document.createElement("ul");
    warnings.forEach(warning => ul.appendChild(bucFullText("li", warning)));
    container.appendChild(ul);
}

function bucFullRenderUnavailable(report) {
    const container = document.getElementById("unavailable");
    const values = report.unavailableChecks || report.metadata?.unavailable || [];
    document.getElementById("unavailableCount").textContent = values.length;
    container.textContent = "";
    if (!values.length) return container.appendChild(bucFullText("p", "No unavailable fields were recorded.", "muted"));
    const ul = document.createElement("ul");
    values.forEach(value => ul.appendChild(bucFullText("li", value)));
    container.appendChild(ul);
}

async function bucFullRenderKnownSender(report) {
    const container = document.getElementById("knownSenderAction");
    container.textContent = "";
    const email = String(report.metadata?.sender || "").trim().toLowerCase();
    if (!email) return;

    const prefs = await bucGetPreferences();
    const known = prefs.knownSenders.includes(email);
    const button = bucFullText("button", known ? "Remove from known senders" : "Mark sender as known", "small-action");
    button.type = "button";
    const note = bucFullText(
        "span",
        known
            ? "Saved locally. Other checks still run normally."
            : "Known-sender status is only a small local reassuring signal and never bypasses other checks.",
        "muted"
    );

    button.addEventListener("click", async () => {
        button.disabled = true;
        try {
            if (known) await bucRemoveKnownSender(email);
            else await bucAddKnownSender(email);

            if (Number.isInteger(bucFullSourceTabId)) {
                const refreshed = await bucFullMessageTab(
                    bucFullSourceTabId,
                    { type: "REANALYSE_CURRENT_EMAIL" }
                );
                if (refreshed?.ok) {
                    bucFullRender(refreshed);
                    return;
                }
            }

            note.textContent = "Saved locally. Re-check the email to refresh its assessment.";
        } catch (error) {
            note.textContent = `Could not update the known-sender setting: ${String(error.message || error)}`;
        } finally {
            button.disabled = false;
        }
    });

    container.append(button, note);
}

function bucFullFocusRequestedLink() {
    const focusLink = new URLSearchParams(location.search).get("focusLink");
    if (!focusLink) return;
    const target = Array.from(document.querySelectorAll(".link-card")).find(card => card.dataset.linkId === focusLink);
    if (!target) return;
    target.open = true;
    target.classList.add("focus-card");
    target.scrollIntoView({ block: "center" });
}

function bucFullRender(report) {
    loadingEl.classList.add("hidden");
    errorEl.classList.add("hidden");
    reportEl.classList.remove("hidden");

    const level = report.evaluation?.overall || report.level || { key: "unknown", label: "UNKNOWN", icon: "?" };
    const summary = document.getElementById("summaryCard");
    summary.dataset.state = level.key || "unknown";
    document.getElementById("verdict").textContent = `${level.icon || ""} ${level.label || "Result"}`.trim();
    const coverage = report.evaluation?.coverage || { label: "Partial", note: "" };
    document.getElementById("score").textContent = `Check complete · coverage ${coverage.label}`;
    document.getElementById("summaryMessage").textContent = level.key === "no-concerns"
        ? "No obvious concerns were found in the checks that completed. This is not a safety guarantee."
        : level.key === "unknown"
            ? "No strong concern was identified; the result remains unknown rather than verified safe."
            : level.key === "review"
                ? "A few observations are worth reviewing before acting."
                : level.key === "high"
                    ? "Strong evidence deserves attention before you continue."
                    : "BeforeUClick found meaningful evidence worth checking before acting.";

    const provider = report.provider || report.debug?.provider || "Webmail";
    document.getElementById("reportSubtitle").textContent = `${provider} · checked ${new Date(report.analysedAt || Date.now()).toLocaleString()}`;

    const metadata = document.getElementById("metadata");
    metadata.textContent = "";
    const m = report.metadata || {};
    bucFullRow(metadata, "Provider", provider);
    bucFullRow(metadata, "Sender", m.senderName && m.sender ? `${m.senderName} <${m.sender}>` : (m.sender || m.senderName));
    bucFullRow(metadata, "To", (m.recipients?.to || []).join(", "));
    bucFullRow(metadata, "CC", (m.recipients?.cc || []).join(", "));
    bucFullRow(metadata, "BCC", (m.recipients?.bcc || []).join(", "));
    bucFullRow(metadata, "Subject", m.subject);
    bucFullRow(metadata, "Date", m.date);
    bucFullRow(metadata, "Reply-To", m.replyTo);
    bucFullRow(metadata, "Mailed-by", m.mailedBy);
    bucFullRow(metadata, "Signed-by", m.signedBy);

    bucFullRenderComponents(report);
    bucFullRenderAuthentication(report);
    bucFullRenderEvidence(report);
    bucFullRenderLinks(report);
    bucFullRenderWording(report);
    bucFullRenderScoreBreakdown(report);
    bucFullRenderWarnings(report);
    bucFullRenderUnavailable(report);
    bucFullRenderKnownSender(report);

    const debug = report.debug || {};
    document.getElementById("debug").textContent = [
        `Provider: ${debug.provider || provider}`,
        `Extracted text length: ${debug.extractedTextLength || 0}`,
        `Total links: ${debug.totalLinks || 0}`,
        `Link types: ${JSON.stringify(debug.linkTypeCounts || {})}`,
        `Unavailable metadata: ${(debug.metadataUnavailable || []).join(", ") || "none"}`,
        `Header acquisition: ${JSON.stringify(debug.headerAcquisition || {})}`,
        `Modules: ${JSON.stringify(debug.moduleStatus || {})}`,
        `Score breakdown: ${JSON.stringify(debug.scoreBreakdown || {})}`
    ].join("\n");
    setTimeout(bucFullFocusRequestedLink, 40);
}

(async function initialiseFullReport() {
    try {
        const prefs = await bucGetPreferences();
        bucFullApplyPreferences(prefs);

        const params = new URLSearchParams(location.search);
        const tabId = Number(params.get("sourceTab"));
        if (!Number.isInteger(tabId)) throw new Error("The source webmail tab could not be identified.");
        bucFullSourceTabId = tabId;

        const report = await bucFullMessageTab(tabId, { type: "GET_LAST_REPORT" });
        if (!report?.ok) throw new Error("The checked message is no longer open, or no report is available.");
        bucFullRender(report);
    } catch (error) {
        bucFullError(String(error.message || error));
    }
})();
