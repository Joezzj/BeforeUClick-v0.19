// analysis/wording.js
// Wording-pattern matching. Pattern data and evidence classes live in data/.

/** Returns the central evidence-class definition for one wording group. */
function bucWordingEvidenceDefinition(group) {
    const key = group?.evidenceClass || "WORDING_WEAK";
    return {
        key,
        ...(BUC_REFERENCE_EVIDENCE_CLASSES[key] || BUC_REFERENCE_EVIDENCE_CLASSES.WORDING_WEAK)
    };
}

/** Returns a calibrated starting weight while preserving a few deliberately weak common patterns. */
function bucWordingCategoryWeight(group, matchCount = 1) {
    const definition = bucWordingEvidenceDefinition(group);
    let points = Math.max(0, Number(definition.suggestedPoints) || 0);

    // One urgency phrase is common in legitimate correspondence.
    if (group?.id === "urgency" && matchCount <= 1) points = Math.min(points, 2);

    // Generic greetings are useful context but very weak evidence on their own.
    if (group?.id === "generic-greeting") points = Math.min(points, 1);

    // A bare QR mention is common; multiple matching instructions are more meaningful.
    if (group?.id === "qr-quishing" && matchCount <= 1) points = Math.min(points, 2);

    return points;
}

/** Matches the sourced wording groups and returns explainable, evidence-class-aware results. */
function checkWording(text) {
    const value = String(text || "");
    const matches = [];
    let score = 0;

    for (const group of BUC_WORDING_PATTERN_GROUPS) {
        const phrases = [];

        for (const pattern of group.patterns || []) {
            const result = value.match(pattern);
            if (result?.[0]) phrases.push(result[0]);
        }

        const uniquePhrases = [...new Set(phrases.map(phrase => phrase.trim()))];
        if (!uniquePhrases.length) continue;

        const definition = bucWordingEvidenceDefinition(group);
        const groupScore = bucWordingCategoryWeight(group, uniquePhrases.length);
        matches.push({
            id: group.id,
            label: group.name || group.label || group.id,
            score: groupScore,
            evidenceClass: definition.key,
            strength: definition.strength || "weak",
            matchedPhrases: uniquePhrases,
            matchCount: uniquePhrases.length,
            references: group.references || []
        });
        score += groupScore;
    }

    return {
        score: Math.min(score, BUC_SCORING_MODEL?.wordingCap || 15),
        matches
    };
}
