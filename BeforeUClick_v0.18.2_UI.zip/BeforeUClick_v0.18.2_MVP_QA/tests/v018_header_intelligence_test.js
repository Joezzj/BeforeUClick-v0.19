// v0.18 shared header/authentication regression tests.
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.resolve(__dirname, "..");

function load(file) {
    vm.runInThisContext(fs.readFileSync(path.join(root, file), "utf8"), { filename: file });
}

load("data/public_suffix_rules.js");
load("data/evidence_classes.js");
load("data/organisation_references.js");
load("data/controlled_namespaces.js");
load("data/email_provider_references.js");
load("analysis/evidence.js");
load("analysis/references.js");
load("analysis/sender.js");
load("analysis/domains.js");
load("analysis/metadata.js");
load("analysis/headers/parser.js");
load("analysis/headers/alignment.js");
load("analysis/headers/authentication.js");
load("analysis/headers/evidence.js");
load("analysis/scoring.js");

function assert(condition, message) {
    if (!condition) throw new Error(message);
}

const gmailRaw = [
    "From: Example Billing <billing@example.com>",
    "To: student@example.net",
    "Reply-To: support@example.com",
    "Return-Path: <bounce@example.com>",
    "Message-ID: <gmail-test@example.com>",
    "Authentication-Results: mx.google.com; spf=pass smtp.mailfrom=bounce@example.com; dkim=pass header.d=example.com header.s=s1; dmarc=pass header.from=example.com",
    "DKIM-Signature: v=1; a=rsa-sha256; d=example.com; s=s1; b=abc",
    "Received: from mail.example.com by mx.google.com",
    "Subject: Gmail auth test",
    "Date: Tue, 15 Sep 2026 12:00:00 +1200"
].join("\r\n");

const gmail = bucBuildAuthenticationModel({ status: "full", source: "gmail-show-original", rawHeaders: gmailRaw, limitations: [] }, { sender: "billing@example.com", recipients: {to: [],cc: [],bcc: []} }, "gmail");
const gmailEvidence = analyseAuthentication(gmail);
assert(gmail.spf.result === "pass", "Gmail SPF pass not parsed");
assert(gmail.spf.providerTrusted === true, "Gmail authserv-id should be provider trusted");
assert(gmail.dkim.some(item => item.result === "pass" && item.signingDomain === "example.com"), "Gmail DKIM not parsed");
assert(gmail.dmarc.result === "pass", "Gmail DMARC pass not parsed");
assert(gmail.alignment.spfAligned === true, "Gmail SPF alignment missing");
assert(gmail.alignment.dkimAligned === true, "Gmail DKIM alignment missing");
assert(gmailEvidence.evidence.some(item => item.evidenceClass === "AUTH_SPF_ALIGNED"), "Gmail SPF reassuring evidence missing");
assert(gmailEvidence.evidence.some(item => item.evidenceClass === "AUTH_DKIM_ALIGNED"), "Gmail DKIM reassuring evidence missing");
assert(gmailEvidence.evidence.some(item => item.evidenceClass === "AUTH_DMARC_PASS"), "Gmail DMARC reassuring evidence missing");

const outlookRaw = [
    "From: Microsoft Security <security@microsoft.com>",
    "Return-Path: <bounce@attacker.example>",
    "Message-ID: <outlook-test@microsoft.com>",
    "Authentication-Results: mail.protection.outlook.com; spf=fail smtp.mailfrom=attacker.example; dkim=fail header.d=attacker.example header.s=x; dmarc=fail header.from=microsoft.com",
    "Received: from attacker.example by mail.protection.outlook.com",
    "Subject: Outlook auth test"
].join("\n");

const outlook = bucBuildAuthenticationModel({ status: "full", source: "outlook-view-message-details", rawHeaders: outlookRaw, limitations: [] }, { sender: "security@microsoft.com", recipients: {to: [],cc: [],bcc: []} }, "outlook");
const outlookEvidence = analyseAuthentication(outlook);
assert(outlook.spf.providerTrusted === true, "Outlook authserv-id should be provider trusted");
assert(outlookEvidence.evidence.some(item => item.evidenceClass === "AUTH_SPF_FAIL"), "Outlook SPF fail evidence missing");
assert(outlookEvidence.evidence.some(item => item.evidenceClass === "AUTH_DKIM_FAIL"), "Outlook DKIM fail evidence missing");
assert(outlookEvidence.evidence.some(item => item.evidenceClass === "AUTH_DMARC_FAIL"), "Outlook DMARC fail evidence missing");

const yahooRaw = [
    "From: Store <notice@example.com>",
    "Reply-To: reply@other.example",
    "Authentication-Results: sonic.gate.mail.ne1.yahoo.com; spf=pass smtp.mailfrom=mailer.example.net; dkim=pass header.d=mailer.example.net header.s=y1; dmarc=pass header.from=example.com",
    "Message-ID: <yahoo-test@example.com>",
    "Received: from mailer.example.net by sonic.gate.mail.ne1.yahoo.com",
    "Subject: Yahoo auth test"
].join("\n");

const yahoo = bucBuildAuthenticationModel({ status: "full", source: "yahoo-view-raw-message", rawHeaders: yahooRaw, limitations: [] }, { sender: "notice@example.com", recipients: {to: [],cc: [],bcc: []} }, "yahoo");
const yahooEvidence = analyseAuthentication(yahoo);
assert(yahoo.spf.providerTrusted === true, "Yahoo authserv-id should be provider trusted");
assert(yahoo.dmarc.result === "pass", "Yahoo DMARC not parsed");
assert(yahoo.alignment.spfAligned === false, "Yahoo SPF should be unaligned in test sample");
assert(yahooEvidence.evidence.some(item => item.evidenceClass === "AUTH_DOMAIN_UNALIGNED"), "Yahoo unaligned auth evidence missing");

// Keep the exact authenticated subdomain for inspection while alignment uses the registrable domain.
const exactDomainRaw = [
    "From: Example <sender@example.com>",
    "Authentication-Results: mx.google.com; spf=pass smtp.mailfrom=bounce@mail.example.com; dkim=pass header.d=signing.example.com header.s=sub; dmarc=pass header.from=example.com",
    "Message-ID: <exact-domain@example.com>",
    "Received: from mail.example.com by mx.google.com"
].join("\n");
const exactDomainModel = bucBuildAuthenticationModel(
    { status: "full", source: "gmail-show-original", rawHeaders: exactDomainRaw, limitations: [] },
    { sender: "sender@example.com", recipients: { to: [], cc: [], bcc: [] } },
    "gmail"
);
assert(exactDomainModel.spf.domain === "mail.example.com", `Expected exact SPF domain, got ${exactDomainModel.spf.domain}`);
assert(exactDomainModel.dkim[0]?.signingDomain === "signing.example.com", `Expected exact DKIM signing domain, got ${exactDomainModel.dkim[0]?.signingDomain}`);
assert(exactDomainModel.alignment.spfAligned === true && exactDomainModel.alignment.dkimAligned === true, "Exact subdomains should still align through registrable-domain comparison.");


const reassuringScore = scoreBeforeUClickEvidence({
    senderResult: { evidence: [] },
    metadataResult: { evidence: gmailEvidence.evidence },
    bodyIdentityResult: { evidence: [] },
    wordingResult: { matches: [] },
    links: []
});
assert(reassuringScore.score === 8, `Expected auth-only reassuring score 8, got ${reassuringScore.score}`);
assert(reassuringScore.level.key === "no-concerns", "Aligned authentication should produce a no-obvious-concerns state when no concerns exist");

const concerningScore = scoreBeforeUClickEvidence({
    senderResult: { evidence: [] },
    metadataResult: { evidence: outlookEvidence.evidence },
    bodyIdentityResult: { evidence: [] },
    wordingResult: { matches: [] },
    links: []
});
assert(concerningScore.score >= 35, `Expected authentication failures to reach caution, got ${concerningScore.score}`);

assert(bucIsProviderAuthserv("outlook", "microsoft.evil.example") === false, "Lookalike Outlook authserv-id must not be trusted");
assert(bucIsProviderAuthserv("yahoo", "yahoo.evil.example") === false, "Lookalike Yahoo authserv-id must not be trusted");
assert(bucIsProviderAuthserv("gmail", "mx.google.com") === true, "Google authserv-id should be trusted");

const merged = bucMergeMetadataFromAuthentication({
    sender: "",
    senderName: "",
    recipients: { to: [], cc: [], bcc: [] },
    subject: "",
    date: "",
    replyTo: "",
    mailedBy: "",
    signedBy: "",
    unavailable: ["sender", "replyTo", "mailedBy", "signedBy", "subject", "date"]
}, gmail);
assert(merged.sender === "billing@example.com", "Raw From did not fill sender blank");
assert(merged.replyTo === "support@example.com", "Raw Reply-To did not fill metadata blank");
assert(merged.mailedBy === "example.com", "SPF mail-from did not fill mailedBy blank");
assert(merged.signedBy === "example.com", "DKIM d= did not fill signedBy blank");
assert(!merged.unavailable.includes("replyTo"), "Filled Reply-To still marked unavailable");

console.log("v0.18 header intelligence tests: PASS");
console.log(JSON.stringify({
    gmail: { spf: gmail.spf.result, dkim: gmail.dkim[0]?.result, dmarc: gmail.dmarc.result, evidence: gmailEvidence.evidence.map(x => x.evidenceClass) },
    outlook: { spf: outlook.spf.result, dmarc: outlook.dmarc.result, evidence: outlookEvidence.evidence.map(x => x.evidenceClass) },
    yahoo: { spf: yahoo.spf.result, dmarc: yahoo.dmarc.result, evidence: yahooEvidence.evidence.map(x => x.evidenceClass) }
}, null, 2));
