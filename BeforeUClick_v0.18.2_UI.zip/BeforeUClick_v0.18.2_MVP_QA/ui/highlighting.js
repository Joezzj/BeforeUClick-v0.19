// ui/highlighting.js
// Floating colour + symbol link messaging and link-to-email navigation for BeforeUClick.

let bucCurrentHighlightMode = "concerns";

/**
 * Adds the temporary CSS classes used to outline analysed Gmail links.
 * Colour is supporting UI only: blue means no obvious concerns, grey means unknown,
 * yellow means review, amber means caution and red means high concern. No colour is a safety guarantee.
 */
function bucEnsureHighlightStyles() {
    if (document.getElementById("beforeuclick-highlight-styles")) return;

    const style = document.createElement("style");
    style.id = "beforeuclick-highlight-styles";
    style.textContent = `
        .beforeuclick-link-checked {
            outline: 3px solid #1a73e8 !important;
            outline-offset: 3px !important;
            border-radius: 4px !important;
        }
        .beforeuclick-link-unknown {
            outline: 2px dashed #5f6368 !important;
            outline-offset: 3px !important;
            border-radius: 4px !important;
        }
        .beforeuclick-link-review {
            outline: 3px solid #e0b400 !important;
            outline-offset: 3px !important;
            border-radius: 4px !important;
        }
        .beforeuclick-link-medium {
            outline: 3px solid #f9ab00 !important;
            outline-offset: 3px !important;
            border-radius: 4px !important;
        }
        .beforeuclick-link-high {
            outline: 3px solid #d93025 !important;
            outline-offset: 3px !important;
            border-radius: 4px !important;
        }
        .beforeuclick-link-focus {
            box-shadow: 0 0 0 6px rgba(26, 115, 232, .28) !important;
        }

        .beforeuclick-link-status-badge {
            position: fixed !important;
            z-index: 2147483645 !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 4px !important;
            margin: 0 !important;
            padding: 3px 7px !important;
            border-radius: 999px !important;
            border: 1px solid currentColor !important;
            font: 700 10px/1.35 Arial, Helvetica, sans-serif !important;
            vertical-align: middle !important;
            white-space: nowrap !important;
            box-sizing: border-box !important;
            cursor: help !important;
            user-select: none !important;
            pointer-events: auto !important;
            box-shadow: 0 2px 6px rgba(32,33,36,.18) !important;
            transform: translateZ(0) !important;
        }
        .beforeuclick-link-status-badge[data-state="no-concerns"] {
            color: #174ea6 !important;
            background: #e8f0fe !important;
        }
        .beforeuclick-link-status-badge[data-state="unknown"] {
            color: #4b5563 !important;
            background: #f3f4f6 !important;
        }
        .beforeuclick-link-status-badge[data-state="review"] {
            color: #725a00 !important;
            background: #fff8d8 !important;
        }
        .beforeuclick-link-status-badge[data-state="caution"] {
            color: #8a5300 !important;
            background: #fef7e0 !important;
        }
        .beforeuclick-link-status-badge[data-state="high"] {
            color: #b42318 !important;
            background: #fce8e6 !important;
        }
    `;
    document.documentElement.appendChild(style);
}


let bucLinkBadgePositionListenersInstalled = false;
let bucLinkBadgePositionFrame = 0;
let bucLinkBadgeScrollTimer = 0;
let bucLinkBadgeScrolling = false;

/**
 * Positions one status chip immediately beside the visible linked object.
 * Prefer the right side, then the left, then below the link when viewport space is tight.
 */
function bucPositionLinkStatusBadge(badge, allowShow = true) {
    if (!badge?.dataset?.linkId) return;

    const target = bucGetLinkVisualTarget(badge.dataset.linkId);
    if (!target || !document.contains(target)) {
        badge.style.visibility = "hidden";
        badge.style.pointerEvents = "none";
        return;
    }

    const rect = target.getBoundingClientRect();
    const fullyOffscreen =
        rect.bottom <= 0 ||
        rect.top >= window.innerHeight ||
        rect.right <= 0 ||
        rect.left >= window.innerWidth;

    if (fullyOffscreen || rect.width <= 0 || rect.height <= 0) {
        badge.style.visibility = "hidden";
        badge.style.pointerEvents = "none";
        return;
    }

    // Keep the element measurable while temporarily hidden during active scrolling.
    badge.style.display = "inline-flex";

    const badgeRect = badge.getBoundingClientRect();
    const gap = 6;
    const edge = 8;

    let left = rect.right + gap;
    let top = rect.top + (rect.height - badgeRect.height) / 2;

    if (left + badgeRect.width > window.innerWidth - edge) {
        left = rect.left - badgeRect.width - gap;
    }

    if (left < edge || left + badgeRect.width > window.innerWidth - edge) {
        left = Math.min(
            Math.max(edge, rect.left),
            Math.max(edge, window.innerWidth - badgeRect.width - edge)
        );
        top = rect.bottom + gap;
    }

    if (top + badgeRect.height > window.innerHeight - edge) {
        top = rect.top - badgeRect.height - gap;
    }

    top = Math.max(edge, Math.min(top, window.innerHeight - badgeRect.height - edge));

    badge.style.left = `${Math.round(left)}px`;
    badge.style.top = `${Math.round(top)}px`;

    if (allowShow && !bucLinkBadgeScrolling) {
        badge.style.visibility = "visible";
        badge.style.pointerEvents = "auto";
    } else {
        badge.style.visibility = "hidden";
        badge.style.pointerEvents = "none";
    }
}

/** Repositions every link-status chip in one animation frame. */
function bucPositionAllLinkStatusBadges(allowShow = true) {
    cancelAnimationFrame(bucLinkBadgePositionFrame);
    bucLinkBadgePositionFrame = requestAnimationFrame(() => {
        document.querySelectorAll(".beforeuclick-link-status-badge").forEach(
            badge => bucPositionLinkStatusBadge(badge, allowShow)
        );
    });
}

/** Immediately hides contextual link UI when scrolling begins. */
function bucBeginLinkBadgeScroll() {
    bucLinkBadgeScrolling = true;

    document.querySelectorAll(".beforeuclick-link-status-badge").forEach(badge => {
        badge.style.visibility = "hidden";
        badge.style.pointerEvents = "none";
    });

    if (typeof bucCloseLinkInfoPopover === "function") {
        bucCloseLinkInfoPopover();
    }

    // Keep coordinates fresh while hidden so there is no visible "catch-up" movement.
    bucPositionAllLinkStatusBadges(false);

    clearTimeout(bucLinkBadgeScrollTimer);
    bucLinkBadgeScrollTimer = setTimeout(() => {
        bucLinkBadgeScrolling = false;
        bucPositionAllLinkStatusBadges(true);
    }, 55);
}

/** Installs responsive listeners once for scrolling/resizing dynamic webmail pages. */
function bucInstallLinkBadgePositionListeners() {
    if (bucLinkBadgePositionListenersInstalled) return;
    bucLinkBadgePositionListenersInstalled = true;

    // wheel/touchmove hide the chips before the page visibly moves;
    // scroll catches keyboard/programmatic and nested-container scrolling.
    window.addEventListener("wheel", bucBeginLinkBadgeScroll, { capture: true, passive: true });
    window.addEventListener("touchmove", bucBeginLinkBadgeScroll, { capture: true, passive: true });
    window.addEventListener("scroll", bucBeginLinkBadgeScroll, true);

    window.addEventListener("resize", () => {
        if (typeof bucCloseLinkInfoPopover === "function") {
            bucCloseLinkInfoPopover();
        }
        bucPositionAllLinkStatusBadges(true);
    }, { passive: true });
}

/**
 * Removes all visual highlighting added by BeforeUClick.
 */
function bucClearLinkHighlights() {
    document.querySelectorAll(
        ".beforeuclick-link-checked, .beforeuclick-link-unknown, .beforeuclick-link-review, .beforeuclick-link-medium, .beforeuclick-link-high, .beforeuclick-link-focus"
    ).forEach(element => {
        element.classList.remove(
            "beforeuclick-link-checked",
            "beforeuclick-link-unknown",
            "beforeuclick-link-review",
            "beforeuclick-link-medium",
            "beforeuclick-link-high",
            "beforeuclick-link-focus"
        );
    });

    document.querySelectorAll(".beforeuclick-link-status-badge").forEach(badge => badge.remove());
}

/**
 * Classifies one analysed link for colour-coded highlighting.
 */
function bucLinkHighlightState(link) {
    const assessed = link?.assessment?.assessment;
    if (assessed?.key) {
        const classByKey = {
            "no-concerns": "beforeuclick-link-checked",
            unknown: "beforeuclick-link-unknown",
            review: "beforeuclick-link-review",
            caution: "beforeuclick-link-medium",
            high: "beforeuclick-link-high"
        };
        return {
            key: assessed.key,
            label: assessed.label.replace(/\b\w/g, value => value.toUpperCase()),
            icon: assessed.icon,
            className: classByKey[assessed.key] || "beforeuclick-link-unknown"
        };
    }

    const score = Math.max(0, Number(link?.score) || 0);
    const warnings = link?.warningDetails || [];
    const hasCritical = warnings.some(warning => warning.strength === "critical");
    const hasStrong = warnings.some(warning => warning.strength === "strong");
    const hasMedium = warnings.some(warning => warning.strength === "medium");
    const hasRecognisedReference = Boolean(
        link?.reference?.officialOrganisation || link?.reference?.shortLinkOrganisation || link?.reference?.controlledNamespace
    );

    if (hasCritical || score >= 60) return { key: "high", label: "High concern", icon: "!", className: "beforeuclick-link-high" };
    if (hasStrong || score >= 35) return { key: "caution", label: "Caution", icon: "⚠", className: "beforeuclick-link-medium" };
    if (hasMedium || score >= 20) return { key: "review", label: "Review", icon: "△", className: "beforeuclick-link-review" };
    if (hasRecognisedReference && warnings.length === 0) return { key: "no-concerns", label: "No obvious concerns", icon: "✓", className: "beforeuclick-link-checked" };
    return { key: "unknown", label: "Unknown", icon: "?", className: "beforeuclick-link-unknown" };
}

/**
 * Returns the registered visible target for a link result, falling back to its anchor.
 */
function bucGetLinkVisualTarget(linkId) {
    const entry = bucLinkElementRegistry.get(linkId);
    if (!entry) return null;
    if (entry.visualTarget && document.contains(entry.visualTarget)) return entry.visualTarget;
    if (entry.anchor && document.contains(entry.anchor)) return entry.anchor;
    return null;
}

/**
 * Returns the compact colour+symbol message shown beside a checked link.
 * Blue means no obvious concerns, grey means unknown, yellow means review, amber means caution and red means high concern.
 * Text and symbols are always present so colour is never the only signal.
 */
function bucLinkBadgeMessage(state) {
    if (state.key === "high") return { text: "! High concern", aria: "High concern link" };
    if (state.key === "caution") return { text: "⚠ Caution", aria: "Caution link" };
    if (state.key === "review") return { text: "△ Review", aria: "Link worth reviewing" };
    if (state.key === "no-concerns") return { text: "✓ No obvious concerns", aria: "No obvious link concerns found" };
    return { text: "? Unknown", aria: "Checked link with unknown status" };
}

/**
 * Adds one floating status chip beside the analysed link without changing the email layout.
 * The chip is anchored to the visible text/button/image target and follows it while scrolling.
 */
function bucAddLinkStatusBadge(link, state) {
    if (!link?.id) return null;

    const target = bucGetLinkVisualTarget(link.id);
    if (!target || !document.contains(target)) return null;

    const existing = document.querySelector(
        `.beforeuclick-link-status-badge[data-link-id="${CSS.escape(link.id)}"]`
    );
    if (existing) {
        bucPositionLinkStatusBadge(existing);
        return existing;
    }

    const message = bucLinkBadgeMessage(state);
    const badge = document.createElement("span");
    badge.className = "beforeuclick-link-status-badge";
    badge.dataset.state = state.key;
    badge.dataset.linkId = link.id;
    badge.textContent = message.text;
    badge.setAttribute("role", "note");
    badge.setAttribute("tabindex", "0");
    badge.setAttribute("aria-label", message.aria);
    badge.setAttribute(
        "title",
        `${message.aria}. Hover or keyboard-focus this label for link details.`
    );
    badge.setAttribute("contenteditable", "false");

    // Append to document.body so Gmail/Outlook/Yahoo layout is never shifted by the badge.
    badge.style.visibility = "hidden";
    badge.style.pointerEvents = "none";
    document.body.appendChild(badge);
    bucInstallLinkBadgePositionListeners();

    // Position once now and again next frame after fonts/layout settle.
    bucPositionLinkStatusBadge(badge);
    requestAnimationFrame(() => bucPositionLinkStatusBadge(badge));

    return badge;
}

/**
 * Applies a link highlight mode. "concerns" shows review/caution/high results, "all" shows every
 * checked clickable link, and "off" clears all persistent outlines.
 */
function bucApplyLinkHighlightMode(links, mode = "concerns") {
    bucEnsureHighlightStyles();
    bucClearLinkHighlights();
    bucCurrentHighlightMode = mode;

    if (mode === "off") return;

    (links || []).forEach(link => {
        if (!link.id) return;
        const element = bucGetLinkVisualTarget(link.id);
        if (!element) return;

        const state = bucLinkHighlightState(link);
        if (mode === "concerns" && !["review", "caution", "high"].includes(state.key)) return;
        element.classList.add(state.className);
        bucAddLinkStatusBadge(link, state);
    });

    bucPositionAllLinkStatusBadges();
}

/**
 * Shows every analysed clickable link using its colour-coded state.
 */
function bucShowAllCheckedLinks(links) {
    bucApplyLinkHighlightMode(links, "all");
}

/**
 * Restores the default concerns-only link view.
 */
function bucShowConcernLinks(links) {
    bucApplyLinkHighlightMode(links, "concerns");
}

/**
 * Scrolls the exact visible Gmail link/button/image into view and briefly emphasises it.
 * The permanent colour-coded state is restored afterwards if one is active.
 */
function bucRevealLink(linkId) {
    const element = bucGetLinkVisualTarget(linkId);
    if (!element) return false;

    bucEnsureHighlightStyles();
    element.scrollIntoView({ behavior: (typeof bucCurrentUiPreferences !== "undefined" && bucCurrentUiPreferences.reducedMotion) ? "auto" : "smooth", block: "center", inline: "nearest" });
    element.classList.add("beforeuclick-link-focus");
    setTimeout(() => {
        if (document.contains(element)) element.classList.remove("beforeuclick-link-focus");
    }, 1800);
    return true;
}
