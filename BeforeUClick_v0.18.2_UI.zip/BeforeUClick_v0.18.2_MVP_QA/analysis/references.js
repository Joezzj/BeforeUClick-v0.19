// analysis/references.js
// Organisation/domain lookup helpers for Reference Dataset v1.0.
// Recognition and reassuring score eligibility are deliberately separate concepts.

/** Returns normalised domain-rule objects for one organisation, including legacy fallback data. */
function bucReferenceDomainRules(reference) {
    if (!reference) return [];

    if (Array.isArray(reference.domainRules) && reference.domainRules.length) {
        return reference.domainRules
            .filter(rule => rule?.domain)
            .map(rule => ({
                domain: bucNormaliseHostname(rule.domain),
                roles: [...new Set(rule.roles || [])],
                scoreKeys: [...new Set(rule.scoreKeys || [])],
                notes: rule.notes || ""
            }));
    }

    // Backwards-compatible fallback for older archived datasets.
    return [
        ...(reference.officialDomains || reference.domains || []).map(domain => ({
            domain: bucNormaliseHostname(domain),
            roles: ["first-party", "sender-domain"],
            scoreKeys: ["OFFICIAL_DESTINATION", "OFFICIAL_SENDER_DOMAIN"],
            notes: "Legacy reference entry."
        })),
        ...(reference.officialShortDomains || []).map(domain => ({
            domain: bucNormaliseHostname(domain),
            roles: ["short-link"],
            scoreKeys: ["OFFICIAL_SHORT_LINK"],
            notes: "Legacy short-link entry."
        }))
    ].filter(rule => rule.domain);
}

/** Returns unique domains for one organisation, optionally filtered by role or score key. */
function bucReferenceDomains(reference, { roles = null, scoreKeys = null } = {}) {
    const roleSet = roles ? new Set(roles) : null;
    const scoreSet = scoreKeys ? new Set(scoreKeys) : null;

    return [...new Set(
        bucReferenceDomainRules(reference)
            .filter(rule => {
                if (roleSet && !rule.roles.some(role => roleSet.has(role))) return false;
                if (scoreSet && !rule.scoreKeys.some(key => scoreSet.has(key))) return false;
                return true;
            })
            .map(rule => rule.domain)
            .filter(Boolean)
    )];
}

/** All recognised domains for brand consistency. Kept for compatibility with older modules. */
function bucReferenceDestinationDomains(reference) {
    return bucReferenceDomains(reference);
}

/** Domains suitable as brand/look-alike comparison targets, excluding infrastructure-only entries where possible. */
function bucReferenceSimilarityDomains(reference) {
    const preferred = bucReferenceDomainRules(reference)
        .filter(rule => rule.roles.some(role => ["first-party", "platform", "user-content", "short-link"].includes(role)))
        .map(rule => rule.domain);
    return [...new Set(preferred.length ? preferred : bucReferenceDestinationDomains(reference))];
}

/** Domains explicitly sourced as legitimate sender domains for one organisation. */
function bucReferenceSenderDomains(reference) {
    return bucReferenceDomains(reference, { scoreKeys: ["OFFICIAL_SENDER_DOMAIN"] });
}

/** Domains explicitly eligible for first-party destination reassurance. */
function bucReferenceOfficialDestinationDomains(reference) {
    return bucReferenceDomains(reference, { scoreKeys: ["OFFICIAL_DESTINATION"] });
}

/** Finds all organisation/domain rules that match a hostname, most-specific rule first. */
function bucFindOrganisationDomainMatches(hostname) {
    const host = bucNormaliseHostname(hostname);
    if (!host) return [];

    const matches = [];
    for (const reference of BUC_ORGANISATION_REFERENCES) {
        for (const rule of bucReferenceDomainRules(reference)) {
            if (bucHostnameMatchesDomain(host, rule.domain)) {
                matches.push({ reference, rule });
            }
        }
    }

    return matches.sort((a, b) => b.rule.domain.length - a.rule.domain.length);
}

/** Finds the organisation for any recognised domain role. This is context, not a safety verdict. */
function bucFindRecognisedOrganisation(hostname) {
    return bucFindOrganisationDomainMatches(hostname)[0]?.reference || null;
}

/** Backwards-compatible alias for general organisation recognition. */
function bucFindOfficialOrganisation(hostname) {
    return bucFindRecognisedOrganisation(hostname);
}

/** Finds an organisation only when the hostname is explicitly eligible for destination reassurance. */
function bucFindOfficialDestinationOrganisation(hostname) {
    const match = bucFindOrganisationDomainMatches(hostname)
        .find(item => item.rule.scoreKeys.includes("OFFICIAL_DESTINATION"));
    return match?.reference || null;
}

/** Finds an organisation only when the hostname is explicitly sourced as an official sender domain. */
function bucFindOfficialSenderOrganisation(hostname) {
    const match = bucFindOrganisationDomainMatches(hostname)
        .find(item => item.rule.scoreKeys.includes("OFFICIAL_SENDER_DOMAIN"));
    return match?.reference || null;
}

/** Returns a controlled/moderated namespace record when the hostname sits beneath one. */
function bucFindControlledNamespace(hostname) {
    const host = bucNormaliseHostname(hostname);
    if (!host) return null;

    return BUC_CONTROLLED_NAMESPACES.find(reference =>
        bucHostnameMatchesDomain(host, reference.suffix)
    ) || null;
}

/** Finds organisation references whose names/aliases are explicitly present in visible text. */
function bucFindClaimedOrganisations(text) {
    const value = String(text || "").toLowerCase();
    if (!value) return [];

    return BUC_ORGANISATION_REFERENCES.filter(reference =>
        (reference.aliases || []).some(alias => {
            const escaped = String(alias).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
            return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(value);
        })
    );
}

/** Returns true when a reference summary carries the requested score key. */
function bucReferenceHasScoreKey(referenceSummary, scoreKey) {
    return Boolean(referenceSummary?.scoreKeys?.includes(scoreKey));
}

/** Returns a compact, role-aware reference summary for a destination hostname. */
function bucDescribeDomainReference(hostname) {
    const matches = bucFindOrganisationDomainMatches(hostname);
    const primary = matches[0] || null;
    const officialDestination = matches.find(item => item.rule.scoreKeys.includes("OFFICIAL_DESTINATION")) || null;
    const officialSender = matches.find(item => item.rule.scoreKeys.includes("OFFICIAL_SENDER_DOMAIN")) || null;
    const shortLink = matches.find(item => item.rule.scoreKeys.includes("OFFICIAL_SHORT_LINK")) || null;
    const controlled = bucFindControlledNamespace(hostname);
    const roles = [...new Set(matches.flatMap(item => item.rule.roles))];
    const scoreKeys = [...new Set(matches.flatMap(item => item.rule.scoreKeys))];

    const compactOrganisation = item => item ? ({
        id: item.reference.id,
        name: item.reference.name,
        references: item.reference.references || []
    }) : null;

    return {
        recognisedOrganisation: compactOrganisation(primary),
        officialOrganisation: compactOrganisation(officialDestination),
        senderOrganisation: compactOrganisation(officialSender),
        shortLinkOrganisation: compactOrganisation(shortLink),
        primaryRule: primary ? {
            domain: primary.rule.domain,
            roles: primary.rule.roles,
            scoreKeys: primary.rule.scoreKeys,
            notes: primary.rule.notes || ""
        } : null,
        roles,
        scoreKeys,
        isPlatform: roles.includes("platform"),
        isUserContent: roles.includes("user-content"),
        isInfrastructure: roles.includes("infrastructure"),
        controlledNamespace: controlled ? { ...controlled } : null
    };
}
