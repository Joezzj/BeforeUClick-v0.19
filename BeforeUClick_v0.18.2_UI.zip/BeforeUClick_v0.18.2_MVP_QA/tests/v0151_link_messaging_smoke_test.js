// tests/v0151_link_messaging_smoke_test.js
// Source-level regression test for the v0.15.1 colour + symbol link messaging.

const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");

function text(file) {
    return fs.readFileSync(path.join(root, file), "utf8");
}

const highlighting = text("ui/highlighting.js");
[
    "! High concern",
    "⚠ Caution",
    "✓ No obvious concerns",
    "△ Review",
    "? Unknown",
    "beforeuclick-link-status-badge"
].forEach(value => {
    if (!highlighting.includes(value)) throw new Error(`Missing highlighting message: ${value}`);
});

const popover = text("ui/link_popover.js");
if (!popover.includes("stateBackground")) throw new Error("Popover status background missing.");
if (!popover.includes("bucLinkBadgeMessage")) throw new Error("Popover is not sharing badge wording.");

const report = text("report/report.js");
if (!report.includes("bucFullLinkState")) throw new Error("Full-report link state classifier missing.");
if (!report.includes("${state.icon} Link")) throw new Error("Full-report link symbol missing.");

console.log("v0.15.1 link messaging smoke test: PASS");
