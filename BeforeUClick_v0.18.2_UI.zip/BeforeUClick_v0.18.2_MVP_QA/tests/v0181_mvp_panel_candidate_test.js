// v0.18.1 MVP panel-candidate regression test.
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.resolve(__dirname, "..");
const read = file => fs.readFileSync(path.join(root, file), "utf8");
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const manifest = JSON.parse(read("manifest.json"));
assert(["0.18.1", "0.18.2"].includes(manifest.version), "Expected v0.18.1-compatible manifest.");

const scripts = manifest.content_scripts[0].js;
[
    "analysis/metadata.js",
    "analysis/risk.js",
    "analysis/scoring.js",
    "analysis/evaluation.js",
    "analysis/wording.js",
    "analysis/headers/parser.js",
    "analysis/headers/authentication.js",
    "analysis/headers/evidence.js",
    "adapters/gmail/extraction.js",
    "adapters/outlook/extraction.js",
    "adapters/yahoo/extraction.js",
    "adapters/gmail/headers.js",
    "adapters/outlook/headers.js",
    "adapters/yahoo/headers.js"
].forEach(file => assert(scripts.includes(file), `Missing MVP script: ${file}`));
assert(scripts.indexOf("analysis/evaluation.js") > scripts.indexOf("analysis/scoring.js"), "Evaluation must load after scoring.");

vm.runInThisContext(read("analysis/scoring.js"), { filename: "analysis/scoring.js" });
vm.runInThisContext(read("analysis/evaluation.js"), { filename: "analysis/evaluation.js" });

assert(bucScoreLevel(8).key === "no-concerns", "0-9 should map to No obvious concerns.");
assert(bucScoreLevel(15).key === "unknown", "10-19 should map to Unknown.");
assert(bucScoreLevel(25).key === "review", "20-34 should map to Review.");
assert(bucScoreLevel(40).key === "caution", "35-59 should map to Caution.");
assert(bucScoreLevel(70).key === "high", "60-100 should map to High concern.");

const weak = bucBuildComponentAssessment({
    key: "test",
    label: "Test",
    evidence: [
        { points: 4, strength: "weak", text: "weak 1" },
        { points: 4, strength: "weak", text: "weak 2" },
        { points: 4, strength: "weak", text: "weak 3" }
    ],
    coverage: bucCoverage("complete"),
    weakConcernCap: 8
});
assert(weak.concernScore === 8, "Weak component evidence should be capped.");
assert(weak.assessment.key === "review", "Capped weak evidence should reach Review, not Caution.");

const strong = bucBuildComponentAssessment({
    key: "test",
    label: "Test",
    evidence: [{ points: 18, strength: "strong", text: "strong identity mismatch" }],
    coverage: bucCoverage("complete")
});
assert(strong.assessment.key === "caution", "Strong evidence should enforce at least Caution.");

const limitedPositive = bucBuildComponentAssessment({
    key: "authentication",
    label: "Authentication",
    evidence: [{ points: -7, strength: "positive", text: "passes" }],
    coverage: bucCoverage("limited")
});
assert(limitedPositive.assessment.key === "unknown", "Limited coverage must not appear reassuring.");

const wordingClean = bucBuildComponentAssessment({
    key: "wording",
    label: "Wording",
    evidence: [],
    coverage: bucCoverage("complete"),
    zeroConcernState: "no-concerns"
});
assert(wordingClean.assessment.key === "no-concerns", "Completed clean wording check should support No obvious concerns locally.");

const missingSourceSummary = bucBuildEvaluationSummary({
    scoring: { level: bucVisibleAssessment("unknown"), moduleScores: { wording: 0, links: 0 } },
    modules: {
        extraction: { status: "error" },
        sender: { status: "ok" },
        authentication: { status: "partial" },
        wording: { status: "ok", evidence: [] },
        links: { status: "ok" }
    },
    metadata: { sender: "" },
    senderResult: { evidence: [] },
    metadataResult: { evidence: [] },
    bodyIdentityResult: { evidence: [] },
    authenticationResult: { evidence: [] },
    headerAcquisition: { status: "unavailable" },
    wordingResult: { matches: [] },
    links: []
});
assert(missingSourceSummary.components.sender.coverage.key === "limited", "Missing sender data must not be reported as complete coverage.");
assert(missingSourceSummary.components.wording.coverage.key === "unavailable", "Failed message extraction must make wording coverage unavailable.");

const popup = read("popup.js");
const report = read("report/report.js");
const background = read("background/service_worker.js");
assert(!popup.includes("Evidence score"), "Popup must not expose the numeric score.");
assert(!report.includes("Evidence score ${report.score}"), "Full report summary must not expose the numeric score.");
assert(report.includes("Evaluation diagnostics (developer)") || read("report/report.html").includes("Evaluation diagnostics (developer)"), "Developer diagnostics section missing.");
assert(background.includes('["review", "caution", "high"]'), "Daily review counter should use the five-state model.");

const content = read("content.js");
assert(content.includes("bucBuildEvaluationSummary"), "Content pipeline does not build component evaluations.");
assert(content.includes('message.type === "ANALYSE_CURRENT_EMAIL"'), "Manual check trigger pipeline missing.");
assert(content.includes("recordScan: false"), "Internal refresh must not inflate scan counters.");

const risk = read("analysis/risk.js");
assert(risk.includes("weakAppliedScore"), "Per-link weak evidence cap missing.");

console.log("v0.18.1 MVP panel candidate tests: PASS");
