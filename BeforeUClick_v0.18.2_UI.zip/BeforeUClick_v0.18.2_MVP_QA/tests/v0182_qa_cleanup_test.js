// v0.18.2 QA/cleanup regression test.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const read = file => fs.readFileSync(path.join(root, file), "utf8");
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const manifest = JSON.parse(read("manifest.json"));
assert(manifest.version === "0.18.2", "Expected v0.18.2 manifest.");
assert(manifest.content_scripts[0].js.includes("adapters/gmail/inbox_preview.js"), "Gmail-specific inbox preview should live with the Gmail adapter.");
assert(!manifest.content_scripts[0].js.includes("ui/inbox_preview.js"), "Obsolete inbox-preview path remains in the manifest.");

// Raw-message pages can include the body. The parser must stop at the RFC header/body boundary.
const headerContext = vm.createContext({ console, URL });
vm.runInContext(read("analysis/headers/parser.js"), headerContext, { filename: "analysis/headers/parser.js" });
vm.runInContext(`
    const raw = [
        "Original Message",
        "Return-Path: <bounce@example.com>",
        "Received: from mail.example.com by mx.google.com; Tue, 15 Sep 2026 10:00:00 +0000",
        "Authentication-Results: mx.google.com; spf=pass smtp.mailfrom=example.com; dkim=pass header.d=example.com; dmarc=pass header.from=example.com",
        "From: Example <sender@example.com>",
        "To: user@example.net",
        "Date: Tue, 15 Sep 2026 10:00:00 +0000",
        "Message-ID: <one@example.com>",
        "Subject: Test",
        "",
        "Hello user,",
        "From: attacker@evil.example",
        "Authentication-Results: evil.example; dmarc=pass header.from=evil.example",
        "Body: this is ordinary message text"
    ].join("\\r\\n");

    const block = bucExtractRawHeaderBlock(raw);
    const parsed = bucParseRawHeaders(raw);
    if (block.includes("attacker@evil.example")) throw new Error("Body text leaked into extracted header block.");
    if (bucHeaderFirst(parsed, "from") !== "Example <sender@example.com>") throw new Error("Wrong From header parsed.");
    if (bucHeaderValues(parsed, "authentication-results").length !== 1) throw new Error("Body Authentication-Results was parsed as a real header.");

    const node = { innerText: raw };
    const found = bucFindRawHeaderTextInNodes([node]);
    if (!found || found.includes("Body: this is ordinary message text")) throw new Error("DOM raw-header capture retained message body content.");

    const notAHeaderBlock = ["From: fake@body.example", "This is ordinary body prose."].join("\\r\\n");
    const rejected = bucParseRawHeaders(notAHeaderBlock);
    if (bucHeaderFirst(rejected, "from")) throw new Error("Parser fell back to treating an unisolated body fragment as Internet headers.");
`, headerContext, { filename: "v0182-header-boundary.js" });

// Redirect unwrapping must recognise real provider domains, not look-alike hostnames.
const linkContext = vm.createContext({ console, URL, setTimeout, clearTimeout });
[
    "data/public_suffix_rules.js",
    "analysis/domains.js",
    "adapters/shared/links.js"
].forEach(file => vm.runInContext(read(file), linkContext, { filename: file }));
vm.runInContext(`
    const target = "https://example.com/account";
    const encoded = encodeURIComponent(target);
    const google = "https://www.google.com/url?q=" + encoded;
    const fakeGoogle = "https://evilgoogle.com/url?q=" + encoded;
    const safeLinks = "https://nam01.safelinks.protection.outlook.com/?url=" + encoded;
    const fakeSafeLinks = "https://safelinks.protection.outlook.com.evil.example/?url=" + encoded;

    if (bucUnwrapKnownRedirect(google) !== target) throw new Error("Real Google redirect was not unwrapped.");
    if (bucUnwrapKnownRedirect(fakeGoogle) !== fakeGoogle) throw new Error("Google look-alike hostname was incorrectly trusted for redirect unwrapping.");
    if (bucUnwrapKnownRedirect(safeLinks) !== target) throw new Error("Real Outlook Safe Links URL was not unwrapped.");
    if (bucUnwrapKnownRedirect(fakeSafeLinks) !== fakeSafeLinks) throw new Error("Safe Links look-alike hostname was incorrectly trusted.");
`, linkContext, { filename: "v0182-redirect-domain.js" });

// SPF/DKIM alignment is a registrable-domain relationship, not merely shared brand ownership.
const alignmentContext = vm.createContext({ console, URL });
[
    "data/public_suffix_rules.js",
    "data/organisation_references.js",
    "data/controlled_namespaces.js",
    "data/email_provider_references.js",
    "analysis/domains.js",
    "analysis/references.js",
    "analysis/metadata.js",
    "analysis/headers/parser.js",
    "analysis/headers/alignment.js"
].forEach(file => vm.runInContext(read(file), alignmentContext, { filename: file }));
vm.runInContext(`
    if (!bucHeaderDomainsAligned("mail.example.com", "example.com")) {
        throw new Error("Subdomains of the same registrable domain should align.");
    }
    if (!bucHeaderDomainsAligned("sender.example.co.nz", "bounce.example.co.nz")) {
        throw new Error("PSL-aware organisational domains should align.");
    }
    if (bucHeaderDomainsAligned("microsoft.com", "outlook.com")) {
        throw new Error("Different registrable domains must not count as SPF/DKIM aligned merely because one organisation owns both.");
    }
    if (!bucHeaderIdentityDomainsRelated("microsoft.com", "outlook.com")) {
        throw new Error("Reply-To identity relationship should still recognise sourced domains belonging to the same organisation.");
    }
`, alignmentContext, { filename: "v0182-auth-alignment.js" });

const outlookHeaders = read("adapters/outlook/headers.js");
assert(outlookHeaders.includes("finally"), "Outlook details cleanup should run even when capture fails.");
assert(outlookHeaders.includes("bucOutlookCloseMessageDetailsIfOpened(captured.openedByPrototype)"), "Outlook details cleanup call missing.");
assert(outlookHeaders.includes("try { more.click(); }"), "Outlook More-actions menu cleanup is missing when View message details cannot be found.");

const content = read("content.js");
assert(content.includes("if (!bucCheckEngaged && triggerPresent) return;"), "Idle MutationObserver optimisation missing.");
assert(content.includes("if (bucObserverTimer) return;"), "MutationObserver throttle missing.");

const preview = read("adapters/gmail/inbox_preview.js");
assert(preview.includes("bucInboxPreviewStopObserver"), "Disabled inbox preview should disconnect its observer.");
assert(preview.includes('key: "review"'), "Inbox preview should use the five-state Review level for medium evidence.");
assert(preview.includes("return null;"), "Weak sender-only inbox clues should be suppressible.");

const floating = read("ui/report.js");
[
    "bucMetadataRow",
    "bucRecipientText",
    "bucSenderText",
    "bucHumanUnavailable",
    "bucLinkTypeLabel",
    "bucAppendEvidenceRow",
    "bucCreateHighlightLegend"
].forEach(name => assert(!floating.includes(`function ${name}`), `Dead floating-report helper remains: ${name}`));

console.log("v0.18.2 QA/cleanup regression test: PASS");
