// analysis/brands.js
// Brand/organisation consistency checks backed by the role-aware Reference Dataset v1.0.

/**
 * Warns when an organisation is claimed in visible text/hostname but the destination
 * is not any recognised domain belonging to that organisation. Platform domains count
 * as brand-consistent but do not automatically receive reassuring score deductions.
 */
function checkBrandImpersonation(url, visibleText = "") {
    const warnings = [];
    const description = bucDescribeUrl(url);
    if (!description?.hostname) return warnings;

    const hostname = description.hostname;
    const claimed = new Map();

    bucFindClaimedOrganisations(visibleText).forEach(reference => claimed.set(reference.id, reference));

    BUC_ORGANISATION_REFERENCES.forEach(reference => {
        const hostTokens = hostname.split(/[.-]+/).filter(Boolean);
        const mentionsBrand = (reference.aliases || []).some(alias => {
            const compactAlias = alias.toLowerCase().replace(/\s+/g, "");
            return compactAlias.length >= 3 && hostTokens.includes(compactAlias);
        });
        if (mentionsBrand) claimed.set(reference.id, reference);
    });

    claimed.forEach(reference => {
        const recognised = bucReferenceDestinationDomains(reference)
            .some(domain => bucHostnameMatchesDomain(hostname, domain));

        if (!recognised) {
            warnings.push({
                code: "brand-domain-inconsistency",
                score: 35,
                points: 35,
                category: "link",
                source: "brand-reference",
                strength: "strong",
                text: `${reference.name} is referenced, but ${hostname} is not in the sourced domain reference for ${reference.name}.`,
                organisation: reference.name,
                references: reference.references || []
            });
        }
    });

    return warnings;
}
